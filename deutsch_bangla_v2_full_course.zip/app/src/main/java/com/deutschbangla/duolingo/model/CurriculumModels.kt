package com.deutschbangla.duolingo.model

enum class ExerciseType {
    WORD_BANK,
    MULTIPLE_CHOICE,
    MATCH_PAIRS,
    LISTENING,
    SPEAKING,
    FILL_BLANK
}

data class MatchPair(
    val bengali: String,
    val german: String,
    val phonetic: String = ""
)

data class Question(
    val id: String,
    val type: ExerciseType,
    val promptBn: String,
    val targetDe: String,
    val phoneticBn: String,
    val correctAnswer: String,
    val sentenceTemplate: String = "",
    val options: List<String> = emptyList(),
    val pairs: List<MatchPair> = emptyList(),
    val grammarExplanationBn: String = ""
)

data class LessonNode(
    val id: String,
    val unitId: Int,
    val titleBn: String,
    val subtitleDe: String,
    val cefrLevel: String,
    val iconEmoji: String,
    val xpReward: Int = 25,
    val questions: List<Question>
)

data class GuidebookItem(
    val german: String,
    val phoneticBn: String,
    val meaningBn: String,
    val grammarTipBn: String
)

data class CourseUnit(
    val id: Int,
    val cefrLevel: String,
    val shortTag: String,
    val titleBn: String,
    val descriptionBn: String,
    val colorHex: Long,
    val guidebook: List<GuidebookItem>,
    val lessons: List<LessonNode>
)

data class AlphabetItem(
    val letter: String,
    val nameBn: String,
    val wordDe: String,
    val meaningBn: String
)

data class GrammarSection(
    val titleBn: String,
    val subtitleBn: String,
    val rows: List<Triple<String, String, String>>
)

object DeutschCurriculumRepository {

    val alphabetList: List<AlphabetItem> = listOf(
        AlphabetItem("A a", "আ (A)", "der Apfel", "আপেল (ডের আপফেল)"),
        AlphabetItem("B b", "বে (Be)", "das Brot", "রুটি (ডাস ব্রোট)"),
        AlphabetItem("C c", "ৎসে (Tse)", "der Computer", "কম্পিউটার"),
        AlphabetItem("D d", "ডে (De)", "Deutschland", "জার্মানি (ডয়চল্যান্ড)"),
        AlphabetItem("E e", "এ (E)", "der Erfolg", "সাফল্য (ডের এরফলগ)"),
        AlphabetItem("F f", "এফ (Ef)", "die Familie", "পরিবার (ডি ফামিলিয়ে)"),
        AlphabetItem("G g", "গে (Ge)", "Guten Morgen", "শুভ সকাল (গুটেন মর্গেন)"),
        AlphabetItem("H h", "হা (Ha)", "das Haus", "বাড়ি (ডাস হাউস)"),
        AlphabetItem("I i", "ই (I)", "der Ingenieur", "প্রকৌশলী (ইনজেনিওর)"),
        AlphabetItem("J j", "ইয়ট (Yot)", "das Jahr", "বছর (ডাস ইয়ার — J উচ্চারণ 'ইয়')"),
        AlphabetItem("K k", "কা (Ka)", "der Kaffee", "কফি (ডের কাফে)"),
        AlphabetItem("L l", "এল (El)", "das Land", "দেশ (ডাস লান্ড)"),
        AlphabetItem("M m", "এম (Em)", "die Milch", "দুধ (ডি মিল্খ)"),
        AlphabetItem("N n", "এন (En)", "die Nacht", "রাত (ডি নাখট)"),
        AlphabetItem("O o", "ও (O)", "das Obst", "ফলমূল (ডাস ওবস্ট)"),
        AlphabetItem("P p", "পে (Pe)", "das Projekt", "প্রজেক্ট (ডাস প্রোইয়েক্ট)"),
        AlphabetItem("Q q", "কু (Ku)", "die Qualität", "গুণমান (ডি কভালিটেট)"),
        AlphabetItem("R r", "এর (Er)", "die Reise", "ভ্রমণ (ডি রাইজে)"),
        AlphabetItem("S s", "এস (Es)", "die Sonne", "সূর্য (ডি জনে — S শুরুতে 'জ')"),
        AlphabetItem("T t", "টে (Te)", "der Termin", "অ্যাপয়েন্টমেন্ট (ডের টার্মিন)"),
        AlphabetItem("U u", "উ (U)", "die U-Bahn", "মেট্রো রেল (ডি উ-বান)"),
        AlphabetItem("V v", "ফাউ (Fau)", "der Vater", "বাবা (ডের ফাটার — V উচ্চারণ 'ফ')"),
        AlphabetItem("W w", "ভে (Ve)", "das Wasser", "পানি (ডাস ভাসার — W উচ্চারণ 'ভ')"),
        AlphabetItem("X x", "ইক্স (Iks)", "das Xylophon", "জাইলোফোন"),
        AlphabetItem("Y y", "উপসিলন", "das System", "সিস্টেম (ডাস জুস্টেম)"),
        AlphabetItem("Z z", "ৎসেট (Tset)", "der Zug", "ট্রেন (ডের ৎসুগ — Z উচ্চারণ 'ৎস')"),
        AlphabetItem("Ä ä", "এ্যা (Umlaut)", "die Ärztin", "মহিলা ডাক্তার (ডি এয়ার্ৎসটিন)"),
        AlphabetItem("Ö ö", "ওয়ে (Umlaut)", "Österreich", "অস্ট্রিয়া (ওয়েস্টাররাইখ)"),
        AlphabetItem("Ü ü", "উই (Umlaut)", "die Übung", "অনুশীলন (ডি উইবুং)"),
        AlphabetItem("ß", "এসৎসেট (ss)", "die Straße", "রাস্তা (ডি স্ট্রাসে)")
    )

    val grammarSections: List<GrammarSection> = listOf(
        GrammarSection(
            titleBn = "১. জার্মান আর্টিকেল (der, die, das)",
            subtitleBn = "জার্মান ভাষায় প্রতিটি বিশেষ্য (Noun) বড় হাতের অক্ষরে শুরু হয় এবং ৩টি লিঙ্গ অনুসারে আর্টিকেল বসে:",
            rows = listOf(
                Triple("der (পুংলিঙ্গ - Masc)", "der Mann, der Tisch, der Zug", "মানুষটি, টেবিলটি, ট্রেনটি"),
                Triple("die (স্ত্রীলিঙ্গ - Fem)", "die Frau, die Milch, die Straße", "মহিলাটি, দুধ, রাস্তাটি"),
                Triple("das (ক্লীবলিঙ্গ - Neut)", "das Kind, das Wasser, das Brot", "শিশুটি, পানি, রুটি"),
                Triple("die (বহুবচন - Plural)", "die Kinder, die Bücher", "শিশুরা, বইগুলো")
            )
        ),
        GrammarSection(
            titleBn = "২. জার্মান ৪টি কারক (4 Cases: A1–C1)",
            subtitleBn = "বাক্যে শব্দের ভূমিকার ওপর ভিত্তি করে আর্টিকেল পরিবর্তিত হয়:",
            rows = listOf(
                Triple("Nominativ (কর্তা)", "der / die / das", "Der Mann trinkt Wasser."),
                Triple("Akkusativ (কর্ম)", "den / die / das", "Ich trinke den Kaffee."),
                Triple("Dativ (সম্প্রদান/অধিকরণ)", "dem / der / dem", "Ich fahre mit der U-Bahn."),
                Triple("Genitiv (সম্বন্ধ - B2/C1)", "des (+s) / der / des (+s)", "Aufgrund des Wetters.")
            )
        ),
        GrammarSection(
            titleBn = "৩. সর্বনাম ও ক্রিয়ার রূপ (Pronouns & Verbs)",
            subtitleBn = "sein (হওয়া) এবং লার্নেন (lernen - শেখা) ক্রিয়ার বর্তমান কাল:",
            rows = listOf(
                Triple("ich (আমি)", "ich bin / ich lerne", "আমি হই / আমি শিখি"),
                Triple("du (তুমি - ঘনিষ্ঠ)", "du bist / du lernst", "তুমি হও / তুমি শেখো"),
                Triple("er/sie/es (সে/এটি)", "er ist / er lernt", "সে হয় / সে শেখে"),
                Triple("wir (আমরা)", "wir sind / wir lernen", "আমরা হই / আমরা শিখি"),
                Triple("Sie (আপনি - ফরমাল)", "Sie sind / Sie lernen", "আপনি হন / আপনি শেখেন")
            )
        )
    )

    val units: List<CourseUnit> = listOf(
        // ==================== UNIT 1: A1.1 BEGINNER ====================
        CourseUnit(
            id = 1,
            cefrLevel = "A1.1 • প্রাথমিক স্তর (Beginner)",
            shortTag = "A1.1",
            titleBn = "ইউনিট ১: অভিবাদন ও পরিচয় (Greetings & Intro)",
            descriptionBn = "জার্মান ভাষায় কুশল বিনিময়, নিজের পরিচয় দেওয়া এবং সৌজন্যমূলক কথা শিখুন।",
            colorHex = 0xFF58CC02,
            guidebook = listOf(
                GuidebookItem("Hallo! / Guten Morgen!", "হ্যালো! / গুটেন মর্গেন!", "হ্যালো! / শুভ সকাল!", "সকাল থেকে দুপুর ১২টা পর্যন্ত দেখা হলে Guten Morgen বলা হয়।"),
                GuidebookItem("Ich bin... / Wie heißt du?", "ইখ বিন... / ভি হাইস্ট ডু?", "আমি হলাম... / তোমার নাম কী?", "ß (Eszett) অক্ষরটি দ্বিত্ব 'স' (ss) এর মতো উচ্চারিত হয়।"),
                GuidebookItem("Danke schön / Bitte schön", "ডাঙ্কে শোন / বিটে শোন", "অনেক ধন্যবাদ / আপনাকে স্বাগতম", "ভদ্রতা প্রকাশে জার্মানরা সবসময় Danke এবং Bitte ব্যবহার করে।")
            ),
            lessons = listOf(
                LessonNode(
                    id = "u1_l1",
                    unitId = 1,
                    titleBn = "অভিবাদন ১ (Greetings)",
                    subtitleDe = "Hallo, Guten Morgen, Danke",
                    cefrLevel = "A1.1",
                    iconEmoji = "👋",
                    xpReward = 20,
                    questions = listOf(
                        Question(
                            id = "u1_l1_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘শুভ সকাল’ — এর সঠিক জার্মান কোনটি?",
                            targetDe = "Guten Morgen",
                            phoneticBn = "গুটেন মর্গেন",
                            correctAnswer = "Guten Morgen",
                            options = listOf("Guten Morgen", "Gute Nacht", "Auf Wiedersehen", "Entschuldigung"),
                            grammarExplanationBn = "সকালে দেখা হলে 'Guten Morgen' (শুভ সকাল) এবং ঘুমানোর আগে 'Gute Nacht' (শুভ রাত্রি) বলা হয়।"
                        ),
                        Question(
                            id = "u1_l1_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "শব্দগুলো সাজিয়ে জার্মান বাক্য তৈরি করুন: ‘হ্যালো, আমি অনিক’",
                            targetDe = "Hallo ich bin Anik",
                            phoneticBn = "হ্যালো ইখ বিন অনিক",
                            correctAnswer = "Hallo ich bin Anik",
                            options = listOf("Hallo", "ich", "bin", "Anik", "du", "bist", "Nacht"),
                            grammarExplanationBn = "Ich (ইখ) = আমি, এবং bin (বিন) = হই বা হলাম।"
                        ),
                        Question(
                            id = "u1_l1_q3",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "বাংলা ও জার্মান শব্দের সঠিক জোড়া মেলান",
                            targetDe = "Hallo, Danke, Bitte, Ja, Nein",
                            phoneticBn = "হ্যালো • ডাঙ্কে • বিটে • ইয়া • নাইন",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("হ্যালো", "Hallo"),
                                MatchPair("ধন্যবাদ", "Danke"),
                                MatchPair("দয়া করে / স্বাগতম", "Bitte"),
                                MatchPair("হ্যাঁ", "Ja"),
                                MatchPair("না", "Nein")
                            ),
                            grammarExplanationBn = "এই ৫টি মৌলিক শব্দ প্রতিদিন কথোপকথনে সবচেয়ে বেশি ব্যবহৃত হয়।"
                        ),
                        Question(
                            id = "u1_l1_q4",
                            type = ExerciseType.LISTENING,
                            promptBn = "অডিওটি শুনে জার্মান বাক্যটি সাজান (অর্থ: অনেক ধন্যবাদ এবং বিদায়)",
                            targetDe = "Vielen Dank und Tschüss",
                            phoneticBn = "ফিলেন ডাঙ্ক উন্ড চুস",
                            correctAnswer = "Vielen Dank und Tschüss",
                            options = listOf("Vielen", "Dank", "und", "Tschüss", "Morgen", "Nein"),
                            grammarExplanationBn = "Vielen Dank = অনেক ধন্যবাদ, und = এবং, Tschüss = বিদায়।"
                        ),
                        Question(
                            id = "u1_l1_q5",
                            type = ExerciseType.SPEAKING,
                            promptBn = "উচ্চারণ করুন: শুভ দিন, তুমি কেমন আছো?",
                            targetDe = "Guten Tag wie geht es dir",
                            phoneticBn = "গুটেন টাগ, ভি গেট এস ডিয়ার?",
                            correctAnswer = "Guten Tag wie geht es dir",
                            grammarExplanationBn = "Wie geht es dir? বন্ধুদের কুশল জিজ্ঞেস করতে ব্যবহৃত হয়।"
                        )
                    )
                ),
                LessonNode(
                    id = "u1_l2",
                    unitId = 1,
                    titleBn = "পরিচয় ও দেশ (Identity)",
                    subtitleDe = "Wie heißt du? & Woher kommst du?",
                    cefrLevel = "A1.1",
                    iconEmoji = "🌍",
                    xpReward = 20,
                    questions = listOf(
                        Question(
                            id = "u1_l2_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘তোমার নাম কী?’ — জার্মান ভাষায় কীভাবে জিজ্ঞেস করবেন?",
                            targetDe = "Wie heißt du?",
                            phoneticBn = "ভি হাইস্ট ডু?",
                            correctAnswer = "Wie heißt du?",
                            options = listOf("Wie heißt du?", "Woher kommst du?", "Guten Abend!", "Wie geht es dir?"),
                            grammarExplanationBn = "heißen মানে নাম হওয়া। 'Wie heißt du?' = তোমার নাম কী?"
                        ),
                        Question(
                            id = "u1_l2_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘আমি ভারত থেকে এসেছি এবং বাংলা বলি’",
                            targetDe = "Ich komme aus Indien und spreche Bengalisch",
                            phoneticBn = "ইখ কমে আউস ইন্ডিয়েন উন্ড স্প্রেখে বেঙ্গালিশ",
                            correctAnswer = "Ich komme aus Indien und spreche Bengalisch",
                            options = listOf("Ich", "komme", "aus", "Indien", "und", "spreche", "Bengalisch", "du"),
                            grammarExplanationBn = "Ich komme aus... = আমি ... থেকে এসেছি; Ich spreche... = আমি ... ভাষায় কথা বলি।"
                        ),
                        Question(
                            id = "u1_l2_q3",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "শূন্যস্থান পূরণ করুন: আমি জার্মান ও বাংলা শিখি।",
                            targetDe = "Ich lerne Deutsch und Bengalisch",
                            phoneticBn = "ইখ লের্নে ডয়চ উন্ড বেঙ্গালিশ",
                            sentenceTemplate = "Ich ___ Deutsch und Bengalisch.",
                            correctAnswer = "lerne",
                            options = listOf("lerne", "lernst", "lernt", "lernen"),
                            grammarExplanationBn = "'Ich' (আমি) এর সাথে ক্রিয়ার শেষে '-e' যুক্ত হয়ে 'lerne' হয়।"
                        ),
                        Question(
                            id = "u1_l2_q4",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "সর্বনাম ও ক্রিয়ার সঠিক জোড়া মেলান",
                            targetDe = "ich bin, du bist, wir sind, Sie sind",
                            phoneticBn = "ইখ বিন • ডু বিস্ট • ভিয়ার জিন্ড • জি জিন্ড",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("আমি হই", "ich bin"),
                                MatchPair("তুমি হও", "du bist"),
                                MatchPair("আমরা হই", "wir sind"),
                                MatchPair("আপনি হন (ফরমাল)", "Sie sind"),
                                MatchPair("জার্মান ভাষা", "Deutsch")
                            ),
                            grammarExplanationBn = "জার্মান ভাষায় ফরমাল 'আপনি' বোঝাতে সর্বদা বড় হাতের 'Sie' ব্যবহৃত হয়।"
                        )
                    )
                ),
                LessonNode(
                    id = "u1_l3",
                    unitId = 1,
                    titleBn = "সৌজন্য ও বিদায় (Politeness)",
                    subtitleDe = "Entschuldigung & Auf Wiedersehen",
                    cefrLevel = "A1.1",
                    iconEmoji = "🤝",
                    xpReward = 25,
                    questions = listOf(
                        Question(
                            id = "u1_l3_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "কারো দৃষ্টি আকর্ষণ করতে বা ‘দুঃখিত / ক্ষমা করবেন’ বলতে কোনটি ব্যবহৃত হয়?",
                            targetDe = "Entschuldigung",
                            phoneticBn = "এন্টশুলডিগুং",
                            correctAnswer = "Entschuldigung",
                            options = listOf("Entschuldigung", "Willkommen", "Gute Reise", "Bis bald"),
                            grammarExplanationBn = "Entschuldigung (এন্টশুলডিগুং) মানে Excuse me বা Sorry।"
                        ),
                        Question(
                            id = "u1_l3_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘শুভ সন্ধ্যা এবং আপনাকে স্বাগতম’",
                            targetDe = "Guten Abend und herzlich willkommen",
                            phoneticBn = "গুটেন আবেন্ড উন্ড হেরৎসলিখ ভিলকমেন",
                            correctAnswer = "Guten Abend und herzlich willkommen",
                            options = listOf("Guten", "Abend", "und", "herzlich", "willkommen", "Nacht", "Nein"),
                            grammarExplanationBn = "Guten Abend = শুভ সন্ধ্যা, herzlich willkommen = আন্তরিক স্বাগতম।"
                        ),
                        Question(
                            id = "u1_l3_q3",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "সৌজন্যমূলক শব্দগুলোর জোড়া মেলান",
                            targetDe = "Willkommen, Auf Wiedersehen, Gute Nacht, Bis morgen, Genau",
                            phoneticBn = "ভিলকমেন • আউফ ভিডারজেহেন • গুটে নাখট • বিস মর্গেন • গেনাউ",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("স্বাগতম", "Willkommen"),
                                MatchPair("আবার দেখা হবে", "Auf Wiedersehen"),
                                MatchPair("শুভ রাত্রি", "Gute Nacht"),
                                MatchPair("কাল দেখা হবে", "Bis morgen"),
                                MatchPair("একদম ঠিক", "Genau")
                            ),
                            grammarExplanationBn = "ফরমাল পরিবেশে বিদায় জানাতে 'Auf Wiedersehen' ব্যবহৃত হয়।"
                        ),
                        Question(
                            id = "u1_l3_q4",
                            type = ExerciseType.SPEAKING,
                            promptBn = "উচ্চারণ করুন: আপনি কি ইংরেজি না জার্মান বলেন?",
                            targetDe = "Sprechen Sie Englisch oder Deutsch",
                            phoneticBn = "স্প্রেখেন জি ইংলিশ ওডার ডয়চ?",
                            correctAnswer = "Sprechen Sie Englisch oder Deutsch",
                            grammarExplanationBn = "oder (ওডার) মানে 'অথবা/না কি'।"
                        )
                    )
                )
            )
        ),

        // ==================== UNIT 2: A1.2 BEGINNER ====================
        CourseUnit(
            id = 2,
            cefrLevel = "A1.2 • প্রাথমিক স্তর ২ (Articles & Family)",
            shortTag = "A1.2",
            titleBn = "ইউনিট ২: খাবার, পরিবার ও আর্টিকেল (der/die/das)",
            descriptionBn = "খাবার অর্ডার করা, পরিবারের সদস্যদের নাম, সংখ্যা এবং ৩টি লিঙ্গের আর্টিকেল শিখুন।",
            colorHex = 0xFF0D9488,
            guidebook = listOf(
                GuidebookItem("der Apfel / die Milch / das Wasser", "ডের আপফেল / ডি মিল্খ / ডাস ভাসার", "আপেলটি / দুধ / পানি", "জার্মান ভাষায় প্রতিটি বিশেষ্যের লিঙ্গ নির্দিষ্ট: der (পুং), die (স্ত্রী), das (ক্লীব)।"),
                GuidebookItem("Meine Mutter und mein Vater", "মাইনে মুটার উন্ড মাইন ফাটার", "আমার মা এবং আমার বাবা", "স্ত্রীলিঙ্গ শব্দের আগে meine এবং পুংলিঙ্গ/ক্লীবলিঙ্গ শব্দের আগে mein বসে।"),
                GuidebookItem("eins, zwei, drei, vier, fünf", "আইন্স, ৎসভ্যাই, ড্রাই, ফিয়ার, ফুনফ", "১, ২, ৩, ৪, ৫", "বয়স ও দাম বলার জন্য সংখ্যা অপরিহার্য।")
            ),
            lessons = listOf(
                LessonNode(
                    id = "u2_l1",
                    unitId = 2,
                    titleBn = "খাবার ও পানীয় (Food & Drink)",
                    subtitleDe = "das Wasser, das Brot, der Kaffee",
                    cefrLevel = "A1.2",
                    iconEmoji = "🥐",
                    xpReward = 25,
                    questions = listOf(
                        Question(
                            id = "u2_l1_q1",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "সঠিক আর্টিকেল বসান (পানিটি ঠান্ডা):",
                            targetDe = "Das Wasser ist kalt",
                            phoneticBn = "ডাস ভাসার ইস্ট কাল্ট",
                            sentenceTemplate = "___ Wasser ist kalt.",
                            correctAnswer = "Das",
                            options = listOf("Das", "Der", "Die", "Den"),
                            grammarExplanationBn = "Wasser (পানি) এবং Brot (রুটি) ক্লীবলিঙ্গ (Neuter), তাই এদের আগে 'das' বসে।"
                        ),
                        Question(
                            id = "u2_l1_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘আমি রুটি খাই এবং পানি পান করি’",
                            targetDe = "Ich esse Brot und trinke Wasser",
                            phoneticBn = "ইখ এসে ব্রোট উন্ড ট্রিঙ্কে ভাসার",
                            correctAnswer = "Ich esse Brot und trinke Wasser",
                            options = listOf("Ich", "esse", "Brot", "und", "trinke", "Wasser", "Kaffee", "du"),
                            grammarExplanationBn = "essen = খাওয়া (Ich esse), trinken = পান করা (Ich trinke)।"
                        ),
                        Question(
                            id = "u2_l1_q3",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "খাবার ও পানীয়র নাম আর্টিকেলসহ মেলান",
                            targetDe = "das Wasser, das Brot, der Apfel, die Milch, der Kaffee",
                            phoneticBn = "ডাস ভাসার • ডাস ব্রোট • ডের আপফেল • ডি মিল্খ • ডের কাফে",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("পানি", "das Wasser"),
                                MatchPair("রুটি", "das Brot"),
                                MatchPair("আপেল", "der Apfel"),
                                MatchPair("দুধ", "die Milch"),
                                MatchPair("কফি", "der Kaffee")
                            ),
                            grammarExplanationBn = "বিশেষ্য (Noun) শেখার সময় সবসময় আর্টিকেলসহ (der/die/das) শেখা উচিত।"
                        ),
                        Question(
                            id = "u2_l1_q4",
                            type = ExerciseType.LISTENING,
                            promptBn = "শুনে বাক্যটি সাজান (অর্থ: আমি এক কাপ কফি চাই, দয়া করে)",
                            targetDe = "Ich möchte einen Kaffee bitte",
                            phoneticBn = "ইখ মশটে আইনেন কাফে বিটে",
                            correctAnswer = "Ich möchte einen Kaffee bitte",
                            options = listOf("Ich", "möchte", "einen", "Kaffee", "bitte", "Wasser", "Nein"),
                            grammarExplanationBn = "রেস্তোরাঁয় ভদ্রভাবে কিছু অর্ডার করতে 'Ich möchte...' ব্যবহৃত হয়।"
                        )
                    )
                ),
                LessonNode(
                    id = "u2_l2",
                    unitId = 2,
                    titleBn = "পরিবার ও মানুষ (Family)",
                    subtitleDe = "Mutter, Vater, Bruder, Schwester",
                    cefrLevel = "A1.2",
                    iconEmoji = "👨‍👩‍👧‍👦",
                    xpReward = 25,
                    questions = listOf(
                        Question(
                            id = "u2_l2_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘আমার মা এবং আমার বাবা’ — এর সঠিক জার্মান কোনটি?",
                            targetDe = "Meine Mutter und mein Vater",
                            phoneticBn = "মাইনে মুটার উন্ড মাইন ফাটার",
                            correctAnswer = "Meine Mutter und mein Vater",
                            options = listOf("Meine Mutter und mein Vater", "Mein Mutter und meine Vater", "Der Bruder und die Schwester", "Das Kind spielt"),
                            grammarExplanationBn = "স্ত্রীলিঙ্গ শব্দের (die Mutter) আগে 'meine' এবং পুংলিঙ্গ শব্দের (der Vater) আগে 'mein' বসে।"
                        ),
                        Question(
                            id = "u2_l2_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘আমার এক ভাই এবং এক বোন আছে’",
                            targetDe = "Ich habe einen Bruder und eine Schwester",
                            phoneticBn = "ইখ হাবে আইনেন ব্রুডার উন্ড আইনে শভেস্টার",
                            correctAnswer = "Ich habe einen Bruder und eine Schwester",
                            options = listOf("Ich", "habe", "einen", "Bruder", "und", "eine", "Schwester", "Vater"),
                            grammarExplanationBn = "'haben' (থাকা) ক্রিয়ার পরে কর্মকারক (Akkusativ) হয়: der Bruder -> einen Bruder।"
                        ),
                        Question(
                            id = "u2_l2_q3",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "পরিবারের সদস্যদের জোড়া মেলান",
                            targetDe = "der Vater, die Mutter, der Bruder, die Schwester, die Familie",
                            phoneticBn = "ডের ফাটার • ডি মুটার • ডের ব্রুডার • ডি শভেস্টার • ডি ফামিলিয়ে",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("বাবা", "der Vater"),
                                MatchPair("মা", "die Mutter"),
                                MatchPair("ভাই", "der Bruder"),
                                MatchPair("বোন", "die Schwester"),
                                MatchPair("পরিবার", "die Familie")
                            ),
                            grammarExplanationBn = "চমৎকার! পরিবারের সদস্যদের লিঙ্গ অনুসারে der এবং die ব্যবহৃত হয়।"
                        ),
                        Question(
                            id = "u2_l2_q4",
                            type = ExerciseType.SPEAKING,
                            promptBn = "উচ্চারণ করুন: আমার পরিবার কলকাতায় থাকে",
                            targetDe = "Meine Familie wohnt in Kalkutta",
                            phoneticBn = "মাইনে ফামিলিয়ে ভোন্ট ইন কালকুটা",
                            correctAnswer = "Meine Familie wohnt in Kalkutta",
                            grammarExplanationBn = "wohnen (ভোনেন) মানে বসবাস করা বা থাকা।"
                        )
                    )
                ),
                LessonNode(
                    id = "u2_l3",
                    unitId = 2,
                    titleBn = "সংখ্যা ও বয়স (Numbers & Age)",
                    subtitleDe = "Eins, zwei, drei & Wie alt bist du?",
                    cefrLevel = "A1.2",
                    iconEmoji = "🔢",
                    xpReward = 25,
                    questions = listOf(
                        Question(
                            id = "u2_l3_q1",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "বাংলা ও জার্মান সংখ্যাগুলোর জোড়া মেলান",
                            targetDe = "eins, zwei, drei, vier, fünf",
                            phoneticBn = "আইন্স • ৎসভ্যাই • ড্রাই • ফিয়ার • ফুনফ",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("১ (এক)", "eins"),
                                MatchPair("২ (দুই)", "zwei"),
                                MatchPair("৩ (তিন)", "drei"),
                                MatchPair("৪ (চার)", "vier"),
                                MatchPair("৫ (পাঁচ)", "fünf")
                            ),
                            grammarExplanationBn = "জার্মান সংখ্যা ১ থেকে ৫: eins, zwei, drei, vier, fünf।"
                        ),
                        Question(
                            id = "u2_l3_q2",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘তোমার বয়স কত?’ — জার্মান ভাষায় কীভাবে জিজ্ঞেস করবেন?",
                            targetDe = "Wie alt bist du?",
                            phoneticBn = "ভি আল্ট বিস্ট ডু?",
                            correctAnswer = "Wie alt bist du?",
                            options = listOf("Wie alt bist du?", "Wie viel kostet das?", "Wo wohnst du?", "Wie spät ist es?"),
                            grammarExplanationBn = "alt মানে বয়স বা পুরনো। 'Wie alt bist du?' = তোমার বয়স কত?"
                        ),
                        Question(
                            id = "u2_l3_q3",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘আমার বয়স বিশ বছর’",
                            targetDe = "Ich bin zwanzig Jahre alt",
                            phoneticBn = "ইখ বিন ৎসভানৎসিগ ইয়ারে আল্ট",
                            correctAnswer = "Ich bin zwanzig Jahre alt",
                            options = listOf("Ich", "bin", "zwanzig", "Jahre", "alt", "zehn", "Uhr"),
                            grammarExplanationBn = "zwanzig = ২০ (বিশ), Jahre = বছর।"
                        ),
                        Question(
                            id = "u2_l3_q4",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "শূন্যস্থান পূরণ করুন: সাত, আট, নয়, দশ (৭, ৮, ৯, ১০)",
                            targetDe = "sieben acht neun zehn",
                            phoneticBn = "জিবেন আখট নইন ৎসেন",
                            sentenceTemplate = "sieben, acht, neun, ___",
                            correctAnswer = "zehn",
                            options = listOf("zehn", "zwei", "elf", "zwölf"),
                            grammarExplanationBn = "sieben (৭), acht (৮), neun (৯), zehn (১০)।"
                        )
                    )
                )
            )
        ),

        // ==================== UNIT 3: A2 ELEMENTARY ====================
        CourseUnit(
            id = 3,
            cefrLevel = "A2 • প্রাত্যহিক জীবন (Elementary)",
            shortTag = "A2",
            titleBn = "ইউনিট ৩: কেনাকাটা, দিনচর্চা ও আবহাওয়া (Daily Life)",
            descriptionBn = "দোকানে কেনাকাটা, কার্ডে পেমেন্ট, ঘড়ির সময় বলা এবং আবহাওয়া ও শখ নিয়ে কথা বলুন।",
            colorHex = 0xFF1CB0F6,
            guidebook = listOf(
                GuidebookItem("Wie viel kostet das?", "ভি ফিল কস্টেট ডাস?", "এটার দাম কত?", "দোকানে বা সুপারমার্কেটে যেকোনো জিনিসের দাম জানতে এটি ব্যবহৃত হয়।"),
                GuidebookItem("Ich stehe um sieben Uhr auf.", "ইখ স্টেহে উম জিবেন উয়ার আউফ।", "আমি সকাল ৭টায় ঘুম থেকে উঠি।", "aufstehen একটি বিভাজ্য ক্রিয়া (Separable Verb), তাই 'auf' বাক্যের শেষে বসে।"),
                GuidebookItem("Die Rechnung, bitte!", "ডি রেখনুং, বিটে!", "বিলটি দিন, দয়া করে!", "রেস্তোরাঁয় খাওয়া শেষে বিল চাইতে ব্যবহৃত হয়।")
            ),
            lessons = listOf(
                LessonNode(
                    id = "u3_l1",
                    unitId = 3,
                    titleBn = "কেনাকাটা ও দাম (Shopping)",
                    subtitleDe = "Wie viel kostet das? & Mit Karte",
                    cefrLevel = "A2.1",
                    iconEmoji = "🛍️",
                    xpReward = 30,
                    questions = listOf(
                        Question(
                            id = "u3_l1_q1",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘এটার দাম কত এবং আমি কি কার্ডে পেমেন্ট করতে পারি?’",
                            targetDe = "Wie viel kostet das und kann ich mit Karte zahlen",
                            phoneticBn = "ভি ফিল কস্টেট ডাস উন্ড কান ইখ মিট কার্টে ৎসালেন",
                            correctAnswer = "Wie viel kostet das und kann ich mit Karte zahlen",
                            options = listOf("Wie", "viel", "kostet", "das", "und", "kann", "ich", "mit", "Karte", "zahlen"),
                            grammarExplanationBn = "mit Karte zahlen = কার্ড দিয়ে মূল্য পরিশোধ করা; bar zahlen = নগদে পরিশোধ করা।"
                        ),
                        Question(
                            id = "u3_l1_q2",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "কেনাকাটার শব্দগুলোর জোড়া মেলান",
                            targetDe = "der Supermarkt, die Rechnung, teuer, günstig, bar zahlen",
                            phoneticBn = "ডের সুপারমার্ক্ট • ডি রেখনুং • টয়ার • গুনস্টিগ • বার ৎসালেন",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("সুপারমার্কেট", "der Supermarkt"),
                                MatchPair("বিল / রসিদ", "die Rechnung"),
                                MatchPair("দামি (Expensive)", "teuer"),
                                MatchPair("সাশ্রয়ী (Cheap)", "günstig"),
                                MatchPair("নগদে পেমেন্ট", "bar zahlen")
                            ),
                            grammarExplanationBn = "জার্মানির অনেক ছোট দোকানে এখনো নগদ অর্থ (Bargeld) পছন্দ করা হয়।"
                        ),
                        Question(
                            id = "u3_l1_q3",
                            type = ExerciseType.SPEAKING,
                            promptBn = "উচ্চারণ করুন: বিলটি দিন, দয়া করে",
                            targetDe = "Die Rechnung bitte",
                            phoneticBn = "ডি রেখনুং বিটে",
                            correctAnswer = "Die Rechnung bitte",
                            grammarExplanationBn = "রেস্তোরাঁয় বিল চাইতে 'Die Rechnung, bitte!' বলা হয়।"
                        ),
                        Question(
                            id = "u3_l1_q4",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "শূন্যস্থান পূরণ করুন: এই জ্যাকেটটি অনেক দামি।",
                            targetDe = "Diese Jacke ist sehr teuer",
                            phoneticBn = "ডিজে ইয়াকে ইস্ট জেয়ার টয়ার",
                            sentenceTemplate = "Diese Jacke ist sehr ___.",
                            correctAnswer = "teuer",
                            options = listOf("teuer", "heute", "morgen", "links"),
                            grammarExplanationBn = "sehr teuer = খুব দামি।"
                        )
                    )
                ),
                LessonNode(
                    id = "u3_l2",
                    unitId = 3,
                    titleBn = "দিনচর্চা ও সময় (Daily Routine)",
                    subtitleDe = "Uhrzeit, Aufstehen & Arbeiten",
                    cefrLevel = "A2.1",
                    iconEmoji = "⏰",
                    xpReward = 30,
                    questions = listOf(
                        Question(
                            id = "u3_l2_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘এখন কয়টা বাজে?’ — এর সঠিক জার্মান কোনটি?",
                            targetDe = "Wie spät ist es?",
                            phoneticBn = "ভি শ্পেট ইস্ট এস?",
                            correctAnswer = "Wie spät ist es?",
                            options = listOf("Wie spät ist es?", "Wo ist der Bahnhof?", "Wann kommst du?", "Es ist acht Uhr."),
                            grammarExplanationBn = "'Wie spät ist es?' বা 'Wie viel Uhr ist es?' মানে এখন কয়টা বাজে।"
                        ),
                        Question(
                            id = "u3_l2_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘আমি প্রতিদিন সকাল সাতটায় ঘুম থেকে উঠি’",
                            targetDe = "Ich stehe jeden Tag um sieben Uhr auf",
                            phoneticBn = "ইখ স্টেহে ইয়েডেন টাগ উম জিবেন উয়ার আউফ",
                            correctAnswer = "Ich stehe jeden Tag um sieben Uhr auf",
                            options = listOf("Ich", "stehe", "jeden", "Tag", "um", "sieben", "Uhr", "auf", "mit"),
                            grammarExplanationBn = "সময়ের আগে 'um' বসে (um sieben Uhr = ৭টায়) এবং বিভাজ্য উপসর্গ 'auf' বাক্যের শেষে যায়।"
                        ),
                        Question(
                            id = "u3_l2_q3",
                            type = ExerciseType.LISTENING,
                            promptBn = "শুনে বাক্যটি সাজান (অর্থ: আজ আমি বাসা থেকে কাজ করছি)",
                            targetDe = "Heute arbeite ich von zu Hause",
                            phoneticBn = "হয়টে আরবাইটে ইখ ফন ৎসু হাউজে",
                            correctAnswer = "Heute arbeite ich von zu Hause",
                            options = listOf("Heute", "arbeite", "ich", "von", "zu", "Hause", "morgen"),
                            grammarExplanationBn = "জার্মান বাক্যে সময় (Heute) শুরুতে এলে ক্রিয়া (arbeite) সর্বদা দ্বিতীয় স্থানে থাকে (V2 Rule)!"
                        ),
                        Question(
                            id = "u3_l2_q4",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "সময় বাচক শব্দগুলোর জোড়া মেলান",
                            targetDe = "heute, morgen, gestern, jeden Tag, am Wochenende",
                            phoneticBn = "হয়টে • মর্গেন • গেস্টার্ন • ইয়েডেন টাগ • আম ভখেনএন্ডে",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("আজ (Today)", "heute"),
                                MatchPair("আগামীকাল (Tomorrow)", "morgen"),
                                MatchPair("গতকাল (Yesterday)", "gestern"),
                                MatchPair("প্রতিদিন", "jeden Tag"),
                                MatchPair("সপ্তাহান্তে (Weekend)", "am Wochenende")
                            ),
                            grammarExplanationBn = "মনে রাখবেন: ছোট হাতের 'morgen' = আগামীকাল, আর বড় হাতের 'der Morgen' = সকাল।"
                        )
                    )
                ),
                LessonNode(
                    id = "u3_l3",
                    unitId = 3,
                    titleBn = "আবহাওয়া ও শখ (Weather & Hobbies)",
                    subtitleDe = "Das Wetter, Musik & Sport",
                    cefrLevel = "A2.2",
                    iconEmoji = "☀️",
                    xpReward = 30,
                    questions = listOf(
                        Question(
                            id = "u3_l3_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘আজ আবহাওয়া খুব সুন্দর এবং রোদ উঠছে’ — এর সঠিক জার্মান কোনটি?",
                            targetDe = "Heute ist das Wetter schön und die Sonne scheint.",
                            phoneticBn = "হয়টে ইস্ট ডাস ভেটার শোন উন্ড ডি জনে শাইন্ট।",
                            correctAnswer = "Heute ist das Wetter schön und die Sonne scheint.",
                            options = listOf(
                                "Heute ist das Wetter schön und die Sonne scheint.",
                                "Es regnet heute den ganzen Tag.",
                                "Im Winter schneit es in Berlin.",
                                "Ich habe keinen Regenschirm."
                            ),
                            grammarExplanationBn = "das Wetter = আবহাওয়া, die Sonne scheint = সূর্য কিরণ দিচ্ছে/রোদ উঠছে।"
                        ),
                        Question(
                            id = "u3_l3_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘আমি অবসর সময়ে বই পড়তে এবং গান শুনতে ভালোবাসি’",
                            targetDe = "Ich lese gern Bücher und höre Musik",
                            phoneticBn = "ইখ লেজে গের্ন বুখার উন্ড হোরে মুজিক",
                            correctAnswer = "Ich lese gern Bücher und höre Musik",
                            options = listOf("Ich", "lese", "gern", "Bücher", "und", "höre", "Musik", "Wasser"),
                            grammarExplanationBn = "ক্রিয়ার সাথে 'gern' (গের্ন) যোগ করলে কোনো কিছু 'পছন্দ করা বা ভালোবাসা' বোঝায়।"
                        ),
                        Question(
                            id = "u3_l3_q3",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "শূন্যস্থান পূরণ করুন: বাইরে বৃষ্টি হচ্ছে (It is raining).",
                            targetDe = "Es regnet draußen",
                            phoneticBn = "এস রেগনেট ড্রাউসেন",
                            sentenceTemplate = "Es ___ draußen.",
                            correctAnswer = "regnet",
                            options = listOf("regnet", "trinkt", "spielt", "arbeitet"),
                            grammarExplanationBn = "Es regnet = বৃষ্টি হচ্ছে; Es schneit = তুষারপাত হচ্ছে।"
                        )
                    )
                )
            )
        ),

        // ==================== UNIT 4: B1 INTERMEDIATE ====================
        CourseUnit(
            id = 4,
            cefrLevel = "B1 • মধ্যম স্তর (Intermediate)",
            shortTag = "B1",
            titleBn = "ইউনিট ৪: ভ্রমণ, ট্রেন স্টেশন ও স্বাস্থ্য (Travel & Health)",
            descriptionBn = "জার্মানিতে ট্রেন ও মেট্রোতে ভ্রমণ, শহরের দিকনির্দেশ এবং ডাক্তারের কাছে কথোপকথন।",
            colorHex = 0xFFFF9600,
            guidebook = listOf(
                GuidebookItem("Auf welchem Gleis fährt der Zug ab?", "আউফ ভেলখেম গ্লাইস ফের্ট ডের ৎসুগ আপ?", "ট্রেনটি কোন প্ল্যাটফর্ম থেকে ছাড়ে?", "Gleis মানে রেল প্ল্যাটফর্ম এবং abfahren মানে ট্রেন/বাস ছেড়ে যাওয়া।"),
                GuidebookItem("Gehen Sie geradeaus und dann nach links.", "গেহেন জি গেরাডেআউস উন্ড ডান নাখ লিংকস।", "সোজা যান এবং তারপর বামে ঘুরুন।", "geradeaus = সোজা, nach links = বামে, nach rechts = ডানে।"),
                GuidebookItem("Ich brauche einen Termin beim Arzt.", "ইখ ব্রাউখে আইনেন টার্মিন বাইম আর্ৎসট।", "ডাক্তারের কাছে আমার একটি অ্যাপয়েন্টমেন্ট দরকার।", "beim = bei + dem (Dativ Case)।")
            ),
            lessons = listOf(
                LessonNode(
                    id = "u4_l1",
                    unitId = 4,
                    titleBn = "রেল স্টেশন ও বিমানবন্দর (Transit)",
                    subtitleDe = "Hauptbahnhof, Gleis & Verspätung",
                    cefrLevel = "B1.1",
                    iconEmoji = "🚆",
                    xpReward = 35,
                    questions = listOf(
                        Question(
                            id = "u4_l1_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘বার্লিন যাওয়ার ট্রেনটি কোন প্ল্যাটফর্ম (Gleis) থেকে ছাড়ে?’ — সঠিক জার্মান কোনটি?",
                            targetDe = "Auf welchem Gleis fährt der Zug nach Berlin ab?",
                            phoneticBn = "আউফ ভেলখেম গ্লাইস ফের্ট ডের ৎসুগ নাখ বার্লিন আপ?",
                            correctAnswer = "Auf welchem Gleis fährt der Zug nach Berlin ab?",
                            options = listOf(
                                "Auf welchem Gleis fährt der Zug nach Berlin ab?",
                                "Wo ist das Hotel in Berlin?",
                                "Wann kommt der Bus heute?",
                                "Ich brauche keinen Koffer."
                            ),
                            grammarExplanationBn = "abfahren (ছেড়ে যাওয়া) একটি বিভাজ্য ক্রিয়া — বাক্যের শেষে 'ab' বসে।"
                        ),
                        Question(
                            id = "u4_l1_q2",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "ভ্রমণ সংক্রান্ত শব্দগুলোর জোড়া মেলান",
                            targetDe = "der Bahnhof, der Flughafen, die Fahrkarte, das Gleis, die Verspätung",
                            phoneticBn = "ডের বানহফ • ডের ফ্লুগহাফেন • ডি ফারকার্টে • ডাস গ্লাইস • ডি ফেরশ্পেটুং",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("রেলওয়ে স্টেশন", "der Bahnhof"),
                                MatchPair("বিমানবন্দর", "der Flughafen"),
                                MatchPair("যাত্রার টিকিট", "die Fahrkarte"),
                                MatchPair("প্ল্যাটফর্ম / লাইন", "das Gleis"),
                                MatchPair("বিলম্ব / দেরি", "die Verspätung")
                            ),
                            grammarExplanationBn = "জার্মান ট্রেনে ভ্রমণের সময় 'Gleis' (প্ল্যাটফর্ম) ও 'Verspätung' (দেরি) শব্দ দুটি সবচেয়ে জরুরি।"
                        ),
                        Question(
                            id = "u4_l1_q3",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘দুঃখিত, ট্রেনটি দশ মিনিট দেরিতে চলছে’",
                            targetDe = "Leider hat der Zug zehn Minuten Verspätung",
                            phoneticBn = "লাইডার হাট ডের ৎসুগ ৎসেন মিনিটেন ফেরশ্পেটুং",
                            correctAnswer = "Leider hat der Zug zehn Minuten Verspätung",
                            options = listOf("Leider", "hat", "der", "Zug", "zehn", "Minuten", "Verspätung", "Gleis"),
                            grammarExplanationBn = "Leider = দুর্ভাগ্যবশত/দুঃখিত; Verspätung haben = দেরি হওয়া।"
                        ),
                        Question(
                            id = "u4_l1_q4",
                            type = ExerciseType.SPEAKING,
                            promptBn = "উচ্চারণ করুন: মিউনিখের একটি টিকিট দিন, দয়া করে",
                            targetDe = "Eine Fahrkarte nach München bitte",
                            phoneticBn = "আইনে ফারকার্টে নাখ মুনখেন বিটে",
                            correctAnswer = "Eine Fahrkarte nach München bitte",
                            grammarExplanationBn = "শহরের দিকে যাওয়া বোঝাতে 'nach' বসে (যেমন: nach München, nach Berlin)।"
                        )
                    )
                ),
                LessonNode(
                    id = "u4_l2",
                    unitId = 4,
                    titleBn = "দিকনির্দেশ ও শহর (Directions)",
                    subtitleDe = "Links, rechts, geradeaus & Dativ",
                    cefrLevel = "B1.1",
                    iconEmoji = "🧭",
                    xpReward = 35,
                    questions = listOf(
                        Question(
                            id = "u4_l2_q1",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘প্রথমে সোজা যান এবং তারপর বামে ঘুরুন’",
                            targetDe = "Gehen Sie zuerst geradeaus und dann nach links",
                            phoneticBn = "গেহেন জি ৎসুএরস্ট গেরাডেআউস উন্ড ডান নাখ লিংকস",
                            correctAnswer = "Gehen Sie zuerst geradeaus und dann nach links",
                            options = listOf("Gehen", "Sie", "zuerst", "geradeaus", "und", "dann", "nach", "links", "rechts"),
                            grammarExplanationBn = "zuerst = প্রথমে, geradeaus = সোজা, dann = তারপর, nach links = বামে।"
                        ),
                        Question(
                            id = "u4_l2_q2",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "Dativ কারক দিয়ে শূন্যস্থান পূরণ করুন: আমি মেট্রোতে (die U-Bahn) করে কাজে যাই।",
                            targetDe = "Ich fahre mit der U-Bahn zur Arbeit",
                            phoneticBn = "ইখ ফারে মিট ডের উ-বান ৎসুর আরবাইট",
                            sentenceTemplate = "Ich fahre mit ___ U-Bahn zur Arbeit.",
                            correctAnswer = "der",
                            options = listOf("der", "die", "das", "den"),
                            grammarExplanationBn = "'mit' অব্যয়ের পরে সর্বদা Dativ কারক বসে, তাই স্ত্রীলিঙ্গ 'die U-Bahn' হয়ে যায় 'mit der U-Bahn'!"
                        ),
                        Question(
                            id = "u4_l2_q3",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "দিকনির্দেশ ও স্থানের জোড়া মেলান",
                            targetDe = "geradeaus, nach links, nach rechts, die Apotheke, die Bäckerei",
                            phoneticBn = "গেরাডেআউস • নাখ লিংকস • নাখ রেখটস • ডি আপোথেকে • ডি বেকেরাই",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("সোজা সামনে", "geradeaus"),
                                MatchPair("বাম দিকে", "nach links"),
                                MatchPair("ডান দিকে", "nach rechts"),
                                MatchPair("ওষুধের দোকান", "die Apotheke"),
                                MatchPair("বেকারি", "die Bäckerei")
                            ),
                            grammarExplanationBn = "দিকনির্দেশ চাইতে 'Wo ist die nächste Apotheke?' (সবচেয়ে কাছের ফার্মেসি কোথায়?) বলা হয়।"
                        )
                    )
                ),
                LessonNode(
                    id = "u4_l3",
                    unitId = 4,
                    titleBn = "স্বাস্থ্য ও ডাক্তার (Doctor & Health)",
                    subtitleDe = "Beim Arzt, Termin & Rezept",
                    cefrLevel = "B1.2",
                    iconEmoji = "🩺",
                    xpReward = 35,
                    questions = listOf(
                        Question(
                            id = "u4_l3_q1",
                            type = ExerciseType.LISTENING,
                            promptBn = "শুনে বাক্যটি সাজান (অর্থ: আমার মাথাব্যথা আছে এবং ডাক্তারের অ্যাপয়েন্টমেন্ট দরকার)",
                            targetDe = "Ich habe Kopfschmerzen und brauche einen Termin beim Arzt",
                            phoneticBn = "ইখ হাবে কপফশ্মেরৎসেন উন্ড ব্রাউখে আইনেন টার্মিন বাইম আর্ৎসট",
                            correctAnswer = "Ich habe Kopfschmerzen und brauche einen Termin beim Arzt",
                            options = listOf("Ich", "habe", "Kopfschmerzen", "und", "brauche", "einen", "Termin", "beim", "Arzt"),
                            grammarExplanationBn = "der Termin = অ্যাপয়েন্টমেন্ট, der Arzt = ডাক্তার, Kopfschmerzen = মাথাব্যথা।"
                        ),
                        Question(
                            id = "u4_l3_q2",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "কেউ অসুস্থ হলে তাকে ‘দ্রুত সুস্থ হয়ে উঠুন (Get well soon)!’ বলতে কী বলা হয়?",
                            targetDe = "Gute Besserung!",
                            phoneticBn = "গুটে বেসারুং!",
                            correctAnswer = "Gute Besserung!",
                            options = listOf("Gute Besserung!", "Guten Appetit!", "Gute Reise!", "Herzlichen Glückwunsch!"),
                            grammarExplanationBn = "অসুস্থ ব্যক্তিকে শুভকামনা জানাতে সর্বদা 'Gute Besserung!' বলা হয়।"
                        ),
                        Question(
                            id = "u4_l3_q3",
                            type = ExerciseType.SPEAKING,
                            promptBn = "উচ্চারণ করুন: আমার জ্বর হয়েছে এবং আমি আজ আসতে পারব না",
                            targetDe = "Ich habe Fieber und kann heute nicht kommen",
                            phoneticBn = "ইখ হাবে ফিবার উন্ড কান হয়টে নিখট কমেন",
                            correctAnswer = "Ich habe Fieber und kann heute nicht kommen",
                            grammarExplanationBn = "das Fieber = জ্বর; মোডাল ক্রিয়া 'kann' থাকলে মূল ক্রিয়া 'kommen' বাক্যের শেষে বসে।"
                        )
                    )
                )
            )
        ),

        // ==================== UNIT 5: B2 UPPER-INTERMEDIATE ====================
        CourseUnit(
            id = 5,
            cefrLevel = "B2 • উচ্চ-মধ্যম স্তর (Career & Office)",
            shortTag = "B2",
            titleBn = "ইউনিট ৫: কর্মক্ষেত্র, ইন্টারভিউ ও ক্যারিয়ার (Work & Business)",
            descriptionBn = "জার্মান কোম্পানিতে চাকরির ইন্টারভিউ, সিভি, অফিস মিটিং এবং ফরমাল বিজনেস ইমেইল।",
            colorHex = 0xFFCE82FF,
            guidebook = listOf(
                GuidebookItem("das Vorstellungsgespräch / der Lebenslauf", "ডাস ফরশটেলুংসগেশপ্রেখ / ডের লেবেন্সলাউফ", "চাকরির ইন্টারভিউ / জীবনবৃত্তান্ত (CV)", "জার্মান কর্মক্ষেত্রে সময়ানুবর্তিতা (Pünktlichkeit) এবং স্পষ্ট যোগাযোগ অত্যন্ত গুরুত্বপূর্ণ।"),
                GuidebookItem("Ich arbeite als Softwareentwickler.", "ইখ আরবাইটে আলস সফটওয়্যারএন্টভিকলার।", "আমি একজন সফটওয়্যার ইঞ্জিনিয়ার হিসেবে কাজ করি।", "পেশা বোঝাতে 'arbeiten als...' ব্যবহৃত হয়।"),
                GuidebookItem("Mit freundlichen Grüßen", "মিট ফ্রয়েন্ডলিখেন গ্রুসেন", "বিনীত / শুভেচ্ছান্তে (Kind regards)", "প্রতিটি অফিশিয়াল জার্মান ইমেইল বা চিঠির শেষে এটি লেখা হয়।")
            ),
            lessons = listOf(
                LessonNode(
                    id = "u5_l1",
                    unitId = 5,
                    titleBn = "চাকরির ইন্টারভিউ (Job Interview)",
                    subtitleDe = "Vorstellungsgespräch & Lebenslauf",
                    cefrLevel = "B2.1",
                    iconEmoji = "💼",
                    xpReward = 40,
                    questions = listOf(
                        Question(
                            id = "u5_l1_q1",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘আমি একজন সফটওয়্যার ইঞ্জিনিয়ার হিসেবে কাজ করি এবং আমার তিন বছরের অভিজ্ঞতা আছে’",
                            targetDe = "Ich arbeite als Softwareentwickler und habe drei Jahre Erfahrung",
                            phoneticBn = "ইখ আরবাইটে আলস সফটওয়্যারএন্টভিকলার উন্ড হাবে ড্রাই ইয়ারে এরফারুং",
                            correctAnswer = "Ich arbeite als Softwareentwickler und habe drei Jahre Erfahrung",
                            options = listOf("Ich", "arbeite", "als", "Softwareentwickler", "und", "habe", "drei", "Jahre", "Erfahrung"),
                            grammarExplanationBn = "die Erfahrung / die Berufserfahrung = কাজের অভিজ্ঞতা।"
                        ),
                        Question(
                            id = "u5_l1_q2",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "কর্মক্ষেত্রের পেশাদার শব্দগুলোর জোড়া মেলান",
                            targetDe = "der Lebenslauf, das Vorstellungsgespräch, die Besprechung, das Gehalt, die Abteilung",
                            phoneticBn = "ডের লেবেন্সলাউফ • ডাস ফরশটেলুংসগেশপ্রেখ • ডি বেশপ্রেখুং • ডাস গেহাল্ট • ডি আবটাইলুং",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("জীবনবৃত্তান্ত (CV)", "der Lebenslauf"),
                                MatchPair("চাকরির ইন্টারভিউ", "das Vorstellungsgespräch"),
                                MatchPair("অফিস মিটিং", "die Besprechung"),
                                MatchPair("বেতন (Salary)", "das Gehalt"),
                                MatchPair("বিভাগ (Department)", "die Abteilung")
                            ),
                            grammarExplanationBn = "জার্মান কোম্পানিতে আবেদনের জন্য Lebenslauf (CV) এবং Anschreiben (Cover Letter) প্রয়োজন হয়।"
                        ),
                        Question(
                            id = "u5_l1_q3",
                            type = ExerciseType.SPEAKING,
                            promptBn = "উচ্চারণ করুন: আপনার সময়ের জন্য অনেক ধন্যবাদ",
                            targetDe = "Vielen Dank für Ihre Zeit",
                            phoneticBn = "ফিলেন ডাঙ্ক ফুর ইরে ৎসাইট",
                            correctAnswer = "Vielen Dank für Ihre Zeit",
                            grammarExplanationBn = "ইন্টারভিউ বা মিটিং শেষে সৌজন্য প্রকাশে এটি একটি আদর্শ পেশাদার বাক্য।"
                        )
                    )
                ),
                LessonNode(
                    id = "u5_l2",
                    unitId = 5,
                    titleBn = "অফিস মিটিং ও প্রজেক্ট (Meetings)",
                    subtitleDe = "Besprechung, Frist & Projekt",
                    cefrLevel = "B2.2",
                    iconEmoji = "📊",
                    xpReward = 40,
                    questions = listOf(
                        Question(
                            id = "u5_l2_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘আমাদের শুক্রবারের মধ্যে এই প্রজেক্টটি সম্পন্ন করতে হবে’ — সঠিক B2 জার্মান কোনটি?",
                            targetDe = "Wir müssen dieses Projekt bis Freitag erfolgreich abschließen.",
                            phoneticBn = "ভিয়ার মুসেন ডিজেস প্রজেক্ট বিস ফ্রাইটাগ এরফলগরাইখ আবশ্লিসেন।",
                            correctAnswer = "Wir müssen dieses Projekt bis Freitag erfolgreich abschließen.",
                            options = listOf(
                                "Wir müssen dieses Projekt bis Freitag erfolgreich abschließen.",
                                "Wir haben gestern im Büro Kaffee getrunken.",
                                "Das Projekt beginnt erst nächstes Jahr.",
                                "Können Sie mir bitte den Stift geben?"
                            ),
                            grammarExplanationBn = "abschließen মানে চূড়ান্তভাবে সম্পন্ন করা এবং bis Freitag মানে শুক্রবারের মধ্যে।"
                        ),
                        Question(
                            id = "u5_l2_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘আমি আপনার প্রস্তাবের সাথে সম্পূর্ণ একমত’",
                            targetDe = "Ich stimme Ihrem Vorschlag vollkommen zu",
                            phoneticBn = "ইখ স্টিমে ইরেম ফরশ্লাগ ফলকমেন ৎসু",
                            correctAnswer = "Ich stimme Ihrem Vorschlag vollkommen zu",
                            options = listOf("Ich", "stimme", "Ihrem", "Vorschlag", "vollkommen", "zu", "nicht"),
                            grammarExplanationBn = "zustimmen (+ Dativ) মানে একমত হওয়া; der Vorschlag = প্রস্তাব।"
                        ),
                        Question(
                            id = "u5_l2_q3",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "শূন্যস্থান পূরণ করুন: আমাদের অবশ্যই ডেডলাইন (die Frist) মেনে চলতে হবে।",
                            targetDe = "Wir müssen die Frist unbedingt einhalten",
                            phoneticBn = "ভিয়ার মুসেন ডি ফ্রিস্ট উনবেডিংট আইনহাল্টেন",
                            sentenceTemplate = "Wir müssen die ___ unbedingt einhalten.",
                            correctAnswer = "Frist",
                            options = listOf("Frist", "Milch", "Reise", "Sonne"),
                            grammarExplanationBn = "die Frist einhalten = ডেডলাইন বা সময়সীমা রক্ষা করা।"
                        )
                    )
                ),
                LessonNode(
                    id = "u5_l3",
                    unitId = 5,
                    titleBn = "ফরমাল ইমেইল (Business Email)",
                    subtitleDe = "Sehr geehrte Damen und Herren",
                    cefrLevel = "B2.2",
                    iconEmoji = "✉️",
                    xpReward = 40,
                    questions = listOf(
                        Question(
                            id = "u5_l3_q1",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "ফরমাল ইমেইলের শেষে ‘বিনীত / শুভেচ্ছান্তে (Kind regards)’ লিখতে কোনটি ব্যবহৃত হয়?",
                            targetDe = "Mit freundlichen Grüßen",
                            phoneticBn = "মিট ফ্রয়েন্ডলিখেন গ্রুসেন",
                            sentenceTemplate = "Mit ___ Grüßen",
                            correctAnswer = "freundlichen",
                            options = listOf("freundlichen", "guten", "kleinen", "schnellen"),
                            grammarExplanationBn = "জার্মান অফিশিয়াল ইমেইলের শেষে সবসময় 'Mit freundlichen Grüßen' লেখা হয়।"
                        ),
                        Question(
                            id = "u5_l3_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘ইমেইলের সাথে সংযুক্ত (Attachment) আমার সিভি পাঠালাম’",
                            targetDe = "Im Anhang sende ich Ihnen meinen Lebenslauf",
                            phoneticBn = "ইম আনহাং জেন্ডে ইখ ইনেন মাইনেন লেবেন্সলাউফ",
                            correctAnswer = "Im Anhang sende ich Ihnen meinen Lebenslauf",
                            options = listOf("Im", "Anhang", "sende", "ich", "Ihnen", "meinen", "Lebenslauf", "Buch"),
                            grammarExplanationBn = "Im Anhang = সংযুক্তিতে (In the attachment)।"
                        ),
                        Question(
                            id = "u5_l3_q3",
                            type = ExerciseType.LISTENING,
                            promptBn = "শুনে ফরমাল বাক্যটি সাজান (অর্থ: আপনার দ্রুত উত্তরের জন্য অনেক ধন্যবাদ)",
                            targetDe = "Vielen Dank für Ihre schnelle Rückmeldung",
                            phoneticBn = "ফিলেন ডাঙ্ক ফুর ইরে শ্নেলে রুকমেল্ডুং",
                            correctAnswer = "Vielen Dank für Ihre schnelle Rückmeldung",
                            options = listOf("Vielen", "Dank", "für", "Ihre", "schnelle", "Rückmeldung", "Zeit"),
                            grammarExplanationBn = "die Rückmeldung = ফিডব্যাক বা প্রত্যুত্তর।"
                        )
                    )
                )
            )
        ),

        // ==================== UNIT 6: C1/C2 PROFESSIONAL MASTERY ====================
        CourseUnit(
            id = 6,
            cefrLevel = "C1/C2 • পেশাদার স্তর (Professional Pro)",
            shortTag = "C1/C2",
            titleBn = "ইউনিট ৬: ব্যবসা, প্রযুক্তি ও একাডেমিক মাস্টারি (Pro German)",
            descriptionBn = "কর্পোরেট চুক্তি, কৃত্রিম বুদ্ধিমত্তা, বিজ্ঞান ও উন্নত ব্যাকরণ (Genitiv ও Konjunktiv II)।",
            colorHex = 0xFFFF4B4B,
            guidebook = listOf(
                GuidebookItem("Meines Erachtens ist diese Strategie nachhaltig.", "মাইনেস এরআখটেন্স ইস্ট ডিজে স্ট্রাটেগি নাখহাল্টিগ।", "আমার সুচিন্তিত মতে, এই কৌশলটি টেকসই।", "C1 স্তরে 'Ich denke' এর বদলে 'Meines Erachtens' ব্যবহার করা উচ্চতর ভাষাগত দক্ষতার পরিচয় দেয়।"),
                GuidebookItem("Aufgrund des technologischen Fortschritts...", "আউফগ্রুন্ড ডেস টেখনোলোগিশেন ফরটশ্রিটস...", "প্রযুক্তিগত অগ্রগতির কারণে...", "'Aufgrund' এর পরে সর্বদা Genitiv কারক (des/der) বসে।"),
                GuidebookItem("Wären Sie so freundlich, den Bericht zu prüfen?", "ভেরেন জি জো ফ্রয়েন্ডলিখ, ডেন বেরিখট ৎসু প্রুফেন?", "আপনি কি অনুগ্রহ করে প্রতিবেদনটি যাচাই করবেন?", "Konjunktiv II ব্যবহার করে সর্বোচ্চ মাত্রার ভদ্র অনুরোধ প্রকাশ করা হয়।")
            ),
            lessons = listOf(
                LessonNode(
                    id = "u6_l1",
                    unitId = 6,
                    titleBn = "চুক্তি ও কৌশলগত আলোচনা (Negotiation)",
                    subtitleDe = "Vertragsverhandlung & Strategie",
                    cefrLevel = "C1.1",
                    iconEmoji = "🏛️",
                    xpReward = 50,
                    questions = listOf(
                        Question(
                            id = "u6_l1_q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘আমরা একটি দীর্ঘমেয়াদী ও সফল সহযোগিতার প্রত্যাশা করছি’ — সঠিক C1 জার্মান কোনটি?",
                            targetDe = "Wir freuen uns auf eine langfristige und erfolgreiche Zusammenarbeit.",
                            phoneticBn = "ভিয়ার ফ্রয়েন্ট উনস আউফ আইনে লাংফ্রিস্টিগে উন্ড এরফলগরাইখে ৎসুসামেনআরবাইট।",
                            correctAnswer = "Wir freuen uns auf eine langfristige und erfolgreiche Zusammenarbeit.",
                            options = listOf(
                                "Wir freuen uns auf eine langfristige und erfolgreiche Zusammenarbeit.",
                                "Wir möchten morgen zusammen Fußball spielen.",
                                "Die Arbeit im Büro ist heute leider geschlossen.",
                                "Ich habe den Vertrag noch nicht gelesen."
                            ),
                            grammarExplanationBn = "sich freuen auf (+ Akkusativ) = কোনো কিছুর জন্য আগ্রহের সাথে অপেক্ষা করা; die Zusammenarbeit = সহযোগিতা।"
                        ),
                        Question(
                            id = "u6_l1_q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "C1 বাক্যটি সাজান: ‘আমার মতে এই বিনিয়োগটি অত্যন্ত লাভজনক’",
                            targetDe = "Meines Erachtens ist diese Investition äußerst rentabel",
                            phoneticBn = "মাইনেস এরআখটেন্স ইস্ট ডিজে ইনভেস্টিৎসিওন অয়সারস্ট রেন্টাবেল",
                            correctAnswer = "Meines Erachtens ist diese Investition äußerst rentabel",
                            options = listOf("Meines", "Erachtens", "ist", "diese", "Investition", "äußerst", "rentabel", "klein"),
                            grammarExplanationBn = "Meines Erachtens = আমার বিবেচনায়/মতে; äußerst rentabel = অত্যন্ত লাভজনক।"
                        ),
                        Question(
                            id = "u6_l1_q3",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "কর্পোরেট ও অর্থনৈতিক শব্দগুলোর জোড়া মেলান",
                            targetDe = "die Investition, die Verhandlung, der Vertrag, der Umsatz, die Bedingung",
                            phoneticBn = "ডি ইনভেস্টিৎসিওন • ডি ফেরহান্ডলুং • ডের ফেরট্রাগ • ডের উমজাৎস • ডি বেডিংগুং",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("বিনিয়োগ (Investment)", "die Investition"),
                                MatchPair("আলোচনা (Negotiation)", "die Verhandlung"),
                                MatchPair("চুক্তি (Contract)", "der Vertrag"),
                                MatchPair("মোট আয় (Revenue)", "der Umsatz"),
                                MatchPair("শর্ত (Condition)", "die Bedingung")
                            ),
                            grammarExplanationBn = "ব্যবসায়িক আলোচনায় এই ৫টি পারিভাষিক শব্দ অপরিহার্য।"
                        )
                    )
                ),
                LessonNode(
                    id = "u6_l2",
                    unitId = 6,
                    titleBn = "প্রযুক্তি, বিজ্ঞান ও উদ্ভাবন (AI & Tech)",
                    subtitleDe = "Künstliche Intelligenz & Genitiv",
                    cefrLevel = "C1.2",
                    iconEmoji = "🔬",
                    xpReward = 50,
                    questions = listOf(
                        Question(
                            id = "u6_l2_q1",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "উচ্চতর পেশাদার ও একাডেমিক শব্দগুলোর জোড়া মেলান",
                            targetDe = "die Künstliche Intelligenz, die Nachhaltigkeit, die Vertragsverhandlung, die Marktforschung, die Digitalisierung",
                            phoneticBn = "ডি কুনস্টলিখে ইন্টেলিগেনৎস • ডি নাখহাল্টিগকাইট • ডি ফেরট্রাগসফেরহান্ডলুং • ডি মার্ক্টফরশুং • ডি ডিগিটালিজিরুং",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("কৃত্রিম বুদ্ধিমত্তা (AI)", "die Künstliche Intelligenz"),
                                MatchPair("টেকসই উন্নয়ন", "die Nachhaltigkeit"),
                                MatchPair("চুক্তির আলোচনা", "die Vertragsverhandlung"),
                                MatchPair("বাজার গবেষণা", "die Marktforschung"),
                                MatchPair("ডিজিটাল রূপান্তর", "die Digitalisierung")
                            ),
                            grammarExplanationBn = "জার্মানির প্রকৌশল, গবেষণা ও আইটি খাতে এই শব্দগুলো প্রতিদিন ব্যবহৃত হয়।"
                        ),
                        Question(
                            id = "u6_l2_q2",
                            type = ExerciseType.FILL_BLANK,
                            promptBn = "C1 Genitiv কারক দিয়ে শূন্যস্থান পূরণ করুন (প্রযুক্তিগত অগ্রগতির কারণে অর্থনীতি বদলে যাচ্ছে):",
                            targetDe = "Aufgrund des technologischen Fortschritts verändert sich die Wirtschaft",
                            phoneticBn = "আউফগ্রুন্ড ডেস টেখনোলোগিশেন ফরটশ্রিটস ফেরএন্ডার্ট জিখ ডি ভির্টশাফট",
                            sentenceTemplate = "Aufgrund ___ technologischen Fortschritts verändert sich die Wirtschaft.",
                            correctAnswer = "des",
                            options = listOf("des", "dem", "den", "die"),
                            grammarExplanationBn = "পুংলিঙ্গ 'der Fortschritt' (অগ্রগতি) Genitiv কারকে 'des Fortschritts' রূপ ধারণ করে।"
                        ),
                        Question(
                            id = "u6_l2_q3",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "অনুবাদ করুন: ‘এই গবেষণার ফলাফলগুলো অত্যন্ত তাৎপর্যপূর্ণ’",
                            targetDe = "Die Ergebnisse dieser Forschung sind äußerst bedeutend",
                            phoneticBn = "ডি এরগেবনিসে ডিজার ফরশুং জিন্ড অয়সারস্ট বেডয়টেন্ড",
                            correctAnswer = "Die Ergebnisse dieser Forschung sind äußerst bedeutend",
                            options = listOf("Die", "Ergebnisse", "dieser", "Forschung", "sind", "äußerst", "bedeutend", "klein"),
                            grammarExplanationBn = "das Ergebnis (বহুবচন: die Ergebnisse) = ফলাফল; die Forschung = গবেষণা।"
                        )
                    )
                ),
                LessonNode(
                    id = "u6_l3",
                    unitId = 6,
                    titleBn = "এক্সিকিউটিভ মাস্টারি (C2 Mastery Boss)",
                    subtitleDe = "Konjunktiv II & Wissenschaft",
                    cefrLevel = "C2",
                    iconEmoji = "👑",
                    xpReward = 60,
                    questions = listOf(
                        Question(
                            id = "u6_l3_q1",
                            type = ExerciseType.LISTENING,
                            promptBn = "শুনে C2 স্তরের বাক্যটি সাজান (অর্থ: আপনি কি অনুগ্রহ করে আগামীকালের মধ্যে প্রতিবেদনটি যাচাই করতে পারবেন?)",
                            targetDe = "Wären Sie so freundlich den Bericht bis morgen zu überprüfen",
                            phoneticBn = "ভেরেন জি জো ফ্রয়েন্ডলিখ ডেন বেরিখট বিস মর্গেন ৎসু উবারপ্রুফেন",
                            correctAnswer = "Wären Sie so freundlich den Bericht bis morgen zu überprüfen",
                            options = listOf("Wären", "Sie", "so", "freundlich", "den", "Bericht", "bis", "morgen", "zu", "überprüfen"),
                            grammarExplanationBn = "'Wären Sie so freundlich... zu...' হলো সর্বোচ্চ মাত্রার ভদ্র ও পেশাদার অনুরোধ (Konjunktiv II)।"
                        ),
                        Question(
                            id = "u6_l3_q2",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘সকল শর্ত পূরণ সাপেক্ষে আমরা চুক্তিতে স্বাক্ষর করতে প্রস্তুত’ — এর সঠিক C2 জার্মান কোনটি?",
                            targetDe = "Unter der Voraussetzung, dass alle Bedingungen erfüllt sind, unterschreiben wir den Vertrag.",
                            phoneticBn = "উন্টার ডের ফরাউসজেৎসুং, ডাস আলে বেডিংগুঙ্গেন এরফুল্ট জিন্ড, উন্টারশ্রাইবেন ভিয়ার ডেন ফেরট্রাগ।",
                            correctAnswer = "Unter der Voraussetzung, dass alle Bedingungen erfüllt sind, unterschreiben wir den Vertrag.",
                            options = listOf(
                                "Unter der Voraussetzung, dass alle Bedingungen erfüllt sind, unterschreiben wir den Vertrag.",
                                "Wir haben gestern einen neuen Kugelschreiber gekauft.",
                                "Wenn es morgen regnet, bleiben wir zu Hause.",
                                "Der Vertrag liegt auf dem Tisch im Büro."
                            ),
                            grammarExplanationBn = "Unter der Voraussetzung, dass... = এই শর্তে যে / সাপেক্ষে (Provided that)।"
                        ),
                        Question(
                            id = "u6_l3_q3",
                            type = ExerciseType.SPEAKING,
                            promptBn = "চূড়ান্ত উচ্চারণ পরীক্ষা: আমরা আমাদের লক্ষ্য সফলভাবে অর্জন করেছি!",
                            targetDe = "Wir haben unser Ziel erfolgreich erreicht",
                            phoneticBn = "ভিয়ার হাবেন উনজার ৎসিল এরফলগরাইখ এররাইখট",
                            correctAnswer = "Wir haben unser Ziel erfolgreich erreicht",
                            grammarExplanationBn = "অভিনন্দন! আপনি প্রাথমিক (A1) থেকে পেশাদার (C1/C2) স্তরের জার্মান কোর্স সম্পন্ন করেছেন!"
                        )
                    )
                )
            )
        )
    )
}
