package com.deutschbangla.duolingo.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DuoGreen = Color(0xFF58CC02)
val DuoGreenDark = Color(0xFF46A302)
val DuoGreenLight = Color(0xFFD7FFB8)
val DuoBlue = Color(0xFF1CB0F6)
val DuoBlueDark = Color(0xFF1899D6)
val DuoBlueLight = Color(0xFFDDF4FF)
val DuoRed = Color(0xFFFF4B4B)
val DuoRedDark = Color(0xFFEA2B2B)
val DuoRedLight = Color(0xFFFFDFE0)
val DuoGold = Color(0xFFFFC800)
val DuoGoldDark = Color(0xFFE5B400)
val DuoGoldLight = Color(0xFFFFF4CC)
val DuoPurple = Color(0xFFCE82FF)
val DuoPurpleDark = Color(0xFFA559D9)
val DuoOrange = Color(0xFFFF9600)
val DuoTeal = Color(0xFF0D9488)
val DuoSurface = Color(0xFFF5F7F9)

private val LightColors = lightColorScheme(
    primary = DuoGreen,
    onPrimary = Color.White,
    secondary = DuoBlue,
    onSecondary = Color.White,
    tertiary = DuoGold,
    error = DuoRed,
    background = DuoSurface,
    surface = Color.White
)

@Composable
fun DeutschBanglaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}
