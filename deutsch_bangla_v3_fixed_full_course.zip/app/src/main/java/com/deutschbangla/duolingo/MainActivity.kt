package com.deutschbangla.duolingo

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.deutschbangla.duolingo.model.*
import com.deutschbangla.duolingo.ui.theme.*
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var toneGenerator: ToneGenerator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this, this)
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
        } catch (_: Exception) {}

        setContent {
            DeutschBanglaTheme {
                DeutschBanglaApp(
                    onSpeakGerman = { text, slow ->
                        tts?.setSpeechRate(if (slow) 0.6f else 0.95f)
                        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "de_tts")
                    },
                    onPlaySound = { isCorrect ->
                        try {
                            if (isCorrect) {
                                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 180)
                            } else {
                                toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 260)
                            }
                        } catch (_: Exception) {}
                    }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.GERMAN
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        toneGenerator?.release()
        super.onDestroy()
    }
}

@Composable
fun DeutschBanglaApp(
    onSpeakGerman: (String, Boolean) -> Unit,
    onPlaySound: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("deutsch_bangla_v2_prefs", Context.MODE_PRIVATE) }

    var selectedTab by remember { mutableIntStateOf(0) }
    var activeLesson by remember { mutableStateOf<LessonNode?>(null) }
    var activeGuidebookUnit by remember { mutableStateOf<CourseUnit?>(null) }
    var selectedUnitFilter by remember { mutableIntStateOf(0) } // 0 = All Units, 1..6 = Unit ID

    // Persistent User Gamification State
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 120)) }
    var dailyXp by remember { mutableIntStateOf(prefs.getInt("dailyXp", 20)) }
    val dailyGoal = 50
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 7)) }
    var gems by remember { mutableIntStateOf(prefs.getInt("gems", 450)) }
    var hearts by remember { mutableIntStateOf(prefs.getInt("hearts", 5)) }
    var unlimitedHearts by remember { mutableStateOf(prefs.getBoolean("unlimitedHearts", false)) }
    var doubleXpBoost by remember { mutableStateOf(prefs.getBoolean("doubleXpBoost", false)) }
    var unlockAllLessons by remember { mutableStateOf(prefs.getBoolean("unlockAllLessons", true)) }

    // Completed lesson crowns map (LessonId -> Crowns)
    val completedCrowns = remember {
        mutableStateMapOf<String, Int>().apply {
            val saved = prefs.getString("completed_crowns", "u1_l1:1") ?: "u1_l1:1"
            saved.split(",").forEach { entry ->
                val parts = entry.split(":")
                if (parts.size == 2) {
                    val c = parts[1].toIntOrNull() ?: 0
                    if (c > 0) put(parts[0], c)
                }
            }
        }
    }

    val claimedChests = remember {
        mutableStateMapOf<Int, Boolean>().apply {
            val saved = prefs.getString("claimed_chests", "") ?: ""
            saved.split(",").forEach { idStr ->
                val id = idStr.toIntOrNull()
                if (id != null) put(id, true)
            }
        }
    }

    fun saveProgress() {
        val crownsStr = completedCrowns.entries.joinToString(",") { "${it.key}:${it.value}" }
        val chestsStr = claimedChests.keys.joinToString(",")
        prefs.edit()
            .putInt("xp", xp)
            .putInt("dailyXp", dailyXp)
            .putInt("streak", streak)
            .putInt("gems", gems)
            .putInt("hearts", hearts)
            .putBoolean("unlimitedHearts", unlimitedHearts)
            .putBoolean("doubleXpBoost", doubleXpBoost)
            .putBoolean("unlockAllLessons", unlockAllLessons)
            .putString("completed_crowns", crownsStr)
            .putString("claimed_chests", chestsStr)
            .apply()
    }

    val units: List<CourseUnit> = remember { DeutschCurriculumRepository.units }
    val totalLessonsCount: Int = remember { units.sumOf { unit: CourseUnit -> unit.lessons.size } }

    BackHandler(enabled = activeLesson != null) {
        activeLesson = null
    }

    // Guidebook Dialog
    if (activeGuidebookUnit != null) {
        val unit = activeGuidebookUnit!!
        Dialog(onDismissRequest = { activeGuidebookUnit = null }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 560.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.0f)) {
                            Text(
                                text = "📖 গাইডবুক • ${unit.cefrLevel}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(unit.colorHex)
                            )
                            Text(
                                text = unit.titleBn,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = DuoDarkText
                            )
                        }
                        IconButton(onClick = { activeGuidebookUnit = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(unit.guidebook) { tip ->
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = DuoSurface),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSpeakGerman(tip.german, false) }
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = tip.german,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 16.sp,
                                            color = DuoDarkText,
                                            modifier = Modifier.weight(1.0f)
                                        )
                                        Text(
                                            text = "🔊 শুনুন",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = DuoBlue
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "উচ্চারণ: ${tip.phoneticBn}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DuoGreenDark
                                    )
                                    Text(
                                        text = "অর্থ: ${tip.meaningBn}",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = DuoDarkText
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "💡 ${tip.grammarTipBn}",
                                        fontSize = 12.sp,
                                        color = Color(0xFF475569)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars),
        topBar = {
            if (activeLesson == null) {
                TopGamificationBar(
                    streak = streak,
                    gems = gems,
                    xp = xp,
                    hearts = hearts,
                    unlimitedHearts = unlimitedHearts
                )
            }
        },
        bottomBar = {
            if (activeLesson == null) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp
                ) {
                    val items = listOf(
                        Triple(0, "শেখার পথ", "🏠"),
                        Triple(1, "বর্ণমালা", "🔤"),
                        Triple(2, "লিডারবোর্ড", "🏆"),
                        Triple(3, "শপ", "🛒"),
                        Triple(4, "প্রোফাইল", "👤")
                    )
                    items.forEach { (index, label, emoji) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Text(text = emoji, fontSize = 20.sp) },
                            label = {
                                Text(
                                    text = label,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DuoSurface)
                .padding(innerPadding)
        ) {
            if (activeLesson != null) {
                LessonScreen(
                    lesson = activeLesson!!,
                    hearts = hearts,
                    unlimitedHearts = unlimitedHearts,
                    doubleXpBoost = doubleXpBoost,
                    onSpeakGerman = onSpeakGerman,
                    onPlaySound = onPlaySound,
                    onLoseHeart = {
                        if (!unlimitedHearts && hearts > 0) {
                            hearts -= 1
                            saveProgress()
                        }
                    },
                    onRefillHearts = {
                        hearts = 5
                        saveProgress()
                    },
                    onComplete = { earnedXp, earnedGems ->
                        xp += earnedXp
                        dailyXp += earnedXp
                        gems += earnedGems
                        val prevCrowns = completedCrowns[activeLesson!!.id] ?: 0
                        completedCrowns[activeLesson!!.id] = prevCrowns + 1
                        saveProgress()
                        activeLesson = null
                    },
                    onClose = { activeLesson = null }
                )
            } else {
                when (selectedTab) {
                    0 -> LearningPathScreen(
                        units = units,
                        selectedUnitFilter = selectedUnitFilter,
                        onSelectUnitFilter = { selectedUnitFilter = it },
                        completedCrowns = completedCrowns,
                        claimedChests = claimedChests,
                        dailyXp = dailyXp,
                        dailyGoal = dailyGoal,
                        unlockAllLessons = unlockAllLessons,
                        onToggleUnlockAll = {
                            unlockAllLessons = !unlockAllLessons
                            saveProgress()
                        },
                        onStartLesson = { lesson ->
                            if (!unlimitedHearts && hearts <= 0) {
                                hearts = 5
                                saveProgress()
                            }
                            activeLesson = lesson
                        },
                        onOpenGuidebook = { unit -> activeGuidebookUnit = unit },
                        onClaimChest = { unitId ->
                            if (claimedChests[unitId] != true) {
                                claimedChests[unitId] = true
                                gems += 50
                                onPlaySound(true)
                                saveProgress()
                            }
                        }
                    )
                    1 -> AlphabetAndGrammarScreen(onSpeakGerman = onSpeakGerman)
                    2 -> LeaderboardScreen(
                        userXp = xp,
                        dailyXp = dailyXp,
                        completedCount = completedCrowns.size,
                        streak = streak,
                        onRewardGems = { bonus ->
                            gems += bonus
                            onPlaySound(true)
                            saveProgress()
                        }
                    )
                    3 -> ShopScreen(
                        gems = gems,
                        hearts = hearts,
                        unlimitedHearts = unlimitedHearts,
                        doubleXpBoost = doubleXpBoost,
                        onBuyHeartRefill = {
                            if (gems >= 100 && hearts < 5) {
                                gems -= 100
                                hearts = 5
                                onPlaySound(true)
                                saveProgress()
                            }
                        },
                        onBuyDoubleXp = {
                            if (gems >= 150 && !doubleXpBoost) {
                                gems -= 150
                                doubleXpBoost = true
                                onPlaySound(true)
                                saveProgress()
                            }
                        },
                        onBuyUnlimitedHearts = {
                            if (gems >= 300 && !unlimitedHearts) {
                                gems -= 300
                                unlimitedHearts = true
                                hearts = 5
                                onPlaySound(true)
                                saveProgress()
                            }
                        }
                    )
                    4 -> ProfileScreen(
                        xp = xp,
                        streak = streak,
                        gems = gems,
                        completedLessons = completedCrowns.size,
                        totalLessons = totalLessonsCount,
                        onResetProgress = {
                            xp = 120
                            dailyXp = 0
                            gems = 450
                            hearts = 5
                            unlimitedHearts = false
                            doubleXpBoost = false
                            completedCrowns.clear()
                            completedCrowns["u1_l1"] = 1
                            claimedChests.clear()
                            saveProgress()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun TopGamificationBar(
    streak: Int,
    gems: Int,
    xp: Int,
    hearts: Int,
    unlimitedHearts: Boolean
) {
    Surface(
        color = Color.White,
        shadowElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "🇩🇪", fontSize = 20.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "ডুও-জার্মান",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = DuoDarkText
                    )
                    Text(
                        text = "A1 → C1 Pro",
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = DuoGreenDark
                    )
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "🔥 $streak", fontWeight = FontWeight.ExtraBold, color = DuoOrange, fontSize = 14.sp)
                Text(text = "💎 $gems", fontWeight = FontWeight.ExtraBold, color = DuoBlue, fontSize = 14.sp)
                Text(text = "⚡ $xp", fontWeight = FontWeight.ExtraBold, color = DuoGoldDark, fontSize = 14.sp)
                Text(
                    text = if (unlimitedHearts) "❤️ ♾️" else "❤️ $hearts",
                    fontWeight = FontWeight.ExtraBold,
                    color = DuoRed,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
fun LearningPathScreen(
    units: List<CourseUnit>,
    selectedUnitFilter: Int,
    onSelectUnitFilter: (Int) -> Unit,
    completedCrowns: Map<String, Int>,
    claimedChests: Map<Int, Boolean>,
    dailyXp: Int,
    dailyGoal: Int,
    unlockAllLessons: Boolean,
    onToggleUnlockAll: () -> Unit,
    onStartLesson: (LessonNode) -> Unit,
    onOpenGuidebook: (CourseUnit) -> Unit,
    onClaimChest: (Int) -> Unit
) {
    val filteredUnits = if (selectedUnitFilter == 0) units else units.filter { it.id == selectedUnitFilter }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Top Welcome & Daily Goal Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(2.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.0f)) {
                            Text(
                                text = "🦉 সম্পূর্ণ জার্মান কোর্স (A1 থেকে C1)",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = DuoDarkText
                            )
                            Text(
                                text = "৬টি ইউনিট • ১৮টি পূর্ণাঙ্গ পাঠ • বাংলা উচ্চারণ ও অডিও",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                        OutlinedButton(
                            onClick = onToggleUnlockAll,
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (unlockAllLessons) "🔓 সব খোলা" else "🔒 ক্রমানুসারে",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { (dailyXp.toFloat() / dailyGoal.toFloat()).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .weight(1.0f)
                                .height(10.dp)
                                .clip(RoundedCornerShape(99.dp)),
                            color = DuoGreen,
                            trackColor = Color(0xFFE2E8F0)
                        )
                        Text(
                            text = "দৈনিক লক্ষ্য: $dailyXp/$dailyGoal XP",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = DuoGreenDark
                        )
                    }
                }
            }
        }

        // Level Filter Chips (All, A1.1, A1.2, A2, B1, B2, C1/C2)
        item {
            val filters = listOf(
                0 to "সব স্তর (All 18)",
                1 to "🌱 A1.1 শুরুর পাঠ",
                2 to "🏡 A1.2 জীবনযাত্রা",
                3 to "🥐 A2 খাবার ও কেনাকাটা",
                4 to "🚆 B1 ভ্রমণ ও স্বাস্থ্য",
                5 to "💼 B2 ক্যারিয়ার ও অফিস",
                6 to "🎓 C1/C2 প্রফেশনাল"
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filters) { (id, label) ->
                    val active = selectedUnitFilter == id
                    FilterChip(
                        selected = active,
                        onClick = { onSelectUnitFilter(id) },
                        label = {
                            Text(
                                text = label,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = DuoGreen,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // Units & Winding Duolingo Lesson Nodes
        itemsIndexed(filteredUnits) { _, unit ->
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Unit Banner Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(unit.colorHex)),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.0f)) {
                            Text(
                                text = unit.cefrLevel,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = unit.titleBn,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = unit.descriptionBn,
                                color = Color.White.copy(alpha = 0.95f),
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onOpenGuidebook(unit) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White.copy(alpha = 0.22f),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(text = "📖 গাইডবুক", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Winding Nodes for Each Lesson in the Unit
                val offsets = listOf(0.dp, (-38).dp, 38.dp)
                unit.lessons.forEachIndexed { idx, lesson ->
                    val crowns = completedCrowns[lesson.id] ?: 0
                    val isUnlocked = unlockAllLessons || crowns > 0 || (unit.id == 1 && idx == 0) ||
                        (idx > 0 && (completedCrowns[unit.lessons[idx - 1].id] ?: 0) > 0)

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .offset(x = offsets[idx % offsets.size])
                            .padding(vertical = 8.dp)
                    ) {
                        Box(contentAlignment = Alignment.TopEnd) {
                            Surface(
                                shape = CircleShape,
                                color = if (isUnlocked) Color(unit.colorHex) else Color(0xFFCBD5E1),
                                shadowElevation = if (isUnlocked) 8.dp else 0.dp,
                                border = BorderStroke(4.dp, Color.White),
                                modifier = Modifier
                                    .size(84.dp)
                                    .clickable(enabled = isUnlocked) { onStartLesson(lesson) }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = if (isUnlocked) lesson.iconEmoji else "🔒",
                                        fontSize = 32.sp
                                    )
                                }
                            }
                            if (crowns > 0) {
                                Surface(
                                    shape = RoundedCornerShape(99.dp),
                                    color = DuoGold,
                                    border = BorderStroke(2.dp, Color.White)
                                ) {
                                    Text(
                                        text = "👑 $crowns",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = DuoDarkText,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = lesson.titleBn,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = DuoDarkText,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "${lesson.subtitleDe} • +${lesson.xpReward} XP",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Unit Bonus Treasure Chest
                val chestClaimed = claimedChests[unit.id] == true
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (chestClaimed) Color(0xFFE2E8F0) else DuoGold,
                        shadowElevation = if (chestClaimed) 0.dp else 6.dp,
                        modifier = Modifier
                            .size(64.dp)
                            .clickable(enabled = !chestClaimed) { onClaimChest(unit.id) }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = if (chestClaimed) "📭" else "🎁", fontSize = 28.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (chestClaimed) "বোনাস সংগৃহীত" else "বোনাস সিন্দুক (+50 💎)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (chestClaimed) Color.Gray else DuoGoldDark
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LessonScreen(
    lesson: LessonNode,
    hearts: Int,
    unlimitedHearts: Boolean,
    doubleXpBoost: Boolean,
    onSpeakGerman: (String, Boolean) -> Unit,
    onPlaySound: (Boolean) -> Unit,
    onLoseHeart: () -> Unit,
    onRefillHearts: () -> Unit,
    onComplete: (Int, Int) -> Unit,
    onClose: () -> Unit
) {
    var qIndex by remember(lesson.id) { mutableIntStateOf(0) }
    var mistakesCount by remember(lesson.id) { mutableIntStateOf(0) }

    val total = lesson.questions.size
    val isFinished = qIndex >= total

    if (isFinished) {
        val earnedXp = if (doubleXpBoost) lesson.xpReward * 2 else lesson.xpReward
        val earnedGems = 25
        val accuracy = (((total - mistakesCount).coerceAtLeast(1) * 100) / total.coerceAtLeast(1)).coerceIn(70, 100)

        LaunchedEffect(lesson.id) {
            onPlaySound(true)
            onSpeakGerman("Herzlichen Glückwunsch!", false)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "🎉", fontSize = 68.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "পাঠ সম্পন্ন হয়েছে! (Ausgezeichnet!)",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = DuoGreenDark,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "${lesson.titleBn} • ${lesson.subtitleDe}",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.Gray,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatRewardBox(title = "অর্জিত XP", value = "+$earnedXp ⚡", color = DuoGoldDark, modifier = Modifier.weight(1.0f))
                StatRewardBox(title = "বোনাস জেমস", value = "+$earnedGems 💎", color = DuoBlue, modifier = Modifier.weight(1.0f))
                StatRewardBox(title = "নির্ভুলতা", value = "$accuracy% 🎯", color = DuoGreenDark, modifier = Modifier.weight(1.0f))
            }

            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = { onComplete(earnedXp, earnedGems) },
                colors = ButtonDefaults.buttonColors(containerColor = DuoGreen),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(
                    text = "শেখার পথে ফিরে যান (Continue)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
            }
        }
        return
    }

    val question = lesson.questions[qIndex]

    // Keyed state per question so switching questions cleanly resets everything
    var selectedAnswer by remember(lesson.id, qIndex) { mutableStateOf("") }
    val wordBankChosenIndices = remember(lesson.id, qIndex) { mutableStateListOf<Int>() }
    var feedbackState by remember(lesson.id, qIndex) { mutableStateOf<Boolean?>(null) }

    // Matching pairs state
    var selectedLeftIdx by remember(lesson.id, qIndex) { mutableStateOf<Int?>(null) }
    var selectedRightIdx by remember(lesson.id, qIndex) { mutableStateOf<Int?>(null) }
    val matchedPairIndices = remember(lesson.id, qIndex) { mutableStateListOf<Int>() }
    val shuffledRightOrder = remember(lesson.id, qIndex) {
        question.pairs.indices.toList().shuffled()
    }

    LaunchedEffect(lesson.id, qIndex) {
        onSpeakGerman(question.targetDe, false)
    }

    fun normalizeText(input: String): String {
        return input.replace(Regex("[.,!?]"), "").trim().lowercase(Locale.ROOT)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Progress Bar & Hearts
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close Lesson")
            }
            LinearProgressIndicator(
                progress = { ((qIndex + 1).toFloat() / total.toFloat()).coerceIn(0.1f, 1f) },
                modifier = Modifier
                    .weight(1.0f)
                    .height(12.dp)
                    .padding(horizontal = 8.dp)
                    .clip(RoundedCornerShape(99.dp)),
                color = DuoGreen,
                trackColor = Color(0xFFE2E8F0)
            )
            Text(
                text = if (unlimitedHearts) "❤️ ♾️" else "❤️ $hearts",
                fontWeight = FontWeight.ExtraBold,
                color = DuoRed,
                fontSize = 15.sp
            )
        }

        // Question Body (Scrollable for small screens)
        Column(
            modifier = Modifier
                .weight(1.0f)
                .verticalScroll(rememberScrollState())
                .padding(vertical = 12.dp)
        ) {
            val badgeText = when (question.type) {
                ExerciseType.MULTIPLE_CHOICE -> "সঠিক উত্তর বাছাই (Multiple Choice)"
                ExerciseType.FILL_BLANK -> "শূন্যস্থান ও ব্যাকরণ (Grammar)"
                ExerciseType.WORD_BANK -> "শব্দ সাজিয়ে বাক্য গঠন (Word Bank)"
                ExerciseType.LISTENING -> "শ্রবণ অনুশীলন (Listening)"
                ExerciseType.MATCH_PAIRS -> "জোড়া মেলান (Tap the Pairs)"
                ExerciseType.SPEAKING -> "উচ্চারণ অনুশীলন (Speaking)"
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = DuoGreenLight,
                    shape = RoundedCornerShape(99.dp)
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DuoGreenDark,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Text(
                    text = "প্রশ্ন ${qIndex + 1}/$total",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = question.promptBn,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = DuoDarkText
            )
            Spacer(modifier = Modifier.height(14.dp))

            // Audio & German Target Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DuoSurface),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(2.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Normal Speed Audio Button
                    Button(
                        onClick = { onSpeakGerman(question.targetDe, false) },
                        colors = ButtonDefaults.buttonColors(containerColor = DuoBlue),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Text(text = "🔊", fontSize = 18.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    // Slow Speed Audio Button (0.6x)
                    OutlinedButton(
                        onClick = { onSpeakGerman(question.targetDe, true) },
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp)
                    ) {
                        Text(text = "🐢", fontSize = 18.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1.0f)) {
                        Text(
                            text = if (question.type == ExerciseType.LISTENING && feedbackState == null)
                                "🔊 অডিওটি শুনে নিচের শব্দগুলো সাজান"
                            else
                                question.targetDe,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = DuoDarkText
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "বাংলা উচ্চারণ: ${question.phoneticBn}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = DuoGreenDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Interactive Zone by ExerciseType
            when (question.type) {
                ExerciseType.MULTIPLE_CHOICE, ExerciseType.FILL_BLANK -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        question.options.forEach { option ->
                            val isSelected = selectedAnswer == option
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) DuoBlueLight else Color.White
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 3.dp else 2.dp,
                                    color = if (isSelected) DuoBlue else Color(0xFFE2E8F0)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = feedbackState == null) {
                                        selectedAnswer = option
                                        onSpeakGerman(option, false)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = option,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isSelected) DuoBlueDark else DuoDarkText,
                                        modifier = Modifier.weight(1.0f)
                                    )
                                    if (isSelected) {
                                        Text(
                                            text = "✓",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = DuoBlueDark
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                ExerciseType.WORD_BANK, ExerciseType.LISTENING -> {
                    // Sentence Tray
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 76.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFFF1F5F9))
                            .border(2.dp, Color(0xFFCBD5E1), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        if (wordBankChosenIndices.isEmpty()) {
                            Text(
                                text = "নিচের শব্দগুলোতে ট্যাপ করে এখানে বাক্য সাজান...",
                                fontSize = 13.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                wordBankChosenIndices.forEachIndexed { pos, optIdx ->
                                    val word = question.options[optIdx]
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = DuoBlueLight,
                                        border = BorderStroke(2.dp, DuoBlue),
                                        modifier = Modifier.clickable(enabled = feedbackState == null) {
                                            wordBankChosenIndices.removeAt(pos)
                                            selectedAnswer = wordBankChosenIndices.joinToString(" ") { question.options[it] }
                                        }
                                    ) {
                                        Text(
                                            text = "$word ✕",
                                            fontWeight = FontWeight.ExtraBold,
                                            color = DuoBlueDark,
                                            fontSize = 15.sp,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Available Word Chips
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        question.options.forEachIndexed { optIdx, word ->
                            val isUsed = wordBankChosenIndices.contains(optIdx)
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isUsed) Color(0xFFE2E8F0) else Color.White,
                                border = BorderStroke(2.dp, if (isUsed) Color(0xFFCBD5E1) else Color(0xFF94A3B8)),
                                modifier = Modifier.clickable(enabled = feedbackState == null && !isUsed) {
                                    onSpeakGerman(word, false)
                                    wordBankChosenIndices.add(optIdx)
                                    selectedAnswer = wordBankChosenIndices.joinToString(" ") { question.options[it] }
                                }
                            ) {
                                Text(
                                    text = word,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isUsed) Color.Transparent else DuoDarkText,
                                    fontSize = 15.sp,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }
                }

                ExerciseType.MATCH_PAIRS -> {
                    Text(
                        text = "বাম পাশের বাংলা শব্দের সাথে ডান পাশের জার্মান শব্দের জোড়া মেলান:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF475569)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Left Column (Bengali)
                        Column(
                            modifier = Modifier.weight(1.0f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            question.pairs.forEachIndexed { idx, pair ->
                                val isMatched = matchedPairIndices.contains(idx)
                                val isSelected = selectedLeftIdx == idx
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = when {
                                            isMatched -> DuoGreenLight
                                            isSelected -> DuoBlueLight
                                            else -> Color.White
                                        }
                                    ),
                                    border = BorderStroke(
                                        width = if (isSelected || isMatched) 2.5.dp else 1.5.dp,
                                        color = when {
                                            isMatched -> DuoGreen
                                            isSelected -> DuoBlue
                                            else -> Color(0xFFCBD5E1)
                                        }
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !isMatched && feedbackState == null) {
                                            selectedLeftIdx = idx
                                            if (selectedRightIdx != null) {
                                                if (selectedRightIdx == idx) {
                                                    matchedPairIndices.add(idx)
                                                    onPlaySound(true)
                                                    if (matchedPairIndices.size == question.pairs.size) {
                                                        selectedAnswer = "MATCHED"
                                                    }
                                                } else {
                                                    onPlaySound(false)
                                                }
                                                selectedLeftIdx = null
                                                selectedRightIdx = null
                                            }
                                        }
                                ) {
                                    Text(
                                        text = if (isMatched) "✓ ${pair.bengali}" else pair.bengali,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        color = if (isMatched) DuoGreenDark else if (isSelected) DuoBlueDark else DuoDarkText,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                        }

                        // Right Column (Shuffled German)
                        Column(
                            modifier = Modifier.weight(1.0f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            shuffledRightOrder.forEach { originalIdx ->
                                val pair = question.pairs[originalIdx]
                                val isMatched = matchedPairIndices.contains(originalIdx)
                                val isSelected = selectedRightIdx == originalIdx
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = when {
                                            isMatched -> DuoGreenLight
                                            isSelected -> DuoBlueLight
                                            else -> Color.White
                                        }
                                    ),
                                    border = BorderStroke(
                                        width = if (isSelected || isMatched) 2.5.dp else 1.5.dp,
                                        color = when {
                                            isMatched -> DuoGreen
                                            isSelected -> DuoBlue
                                            else -> Color(0xFFCBD5E1)
                                        }
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !isMatched && feedbackState == null) {
                                            onSpeakGerman(pair.german, false)
                                            selectedRightIdx = originalIdx
                                            if (selectedLeftIdx != null) {
                                                if (selectedLeftIdx == originalIdx) {
                                                    matchedPairIndices.add(originalIdx)
                                                    onPlaySound(true)
                                                    if (matchedPairIndices.size == question.pairs.size) {
                                                        selectedAnswer = "MATCHED"
                                                    }
                                                } else {
                                                    onPlaySound(false)
                                                }
                                                selectedLeftIdx = null
                                                selectedRightIdx = null
                                            }
                                        }
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = if (isMatched) "✓ ${pair.german}" else pair.german,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 14.sp,
                                            color = if (isMatched) DuoGreenDark else if (isSelected) DuoBlueDark else DuoDarkText
                                        )
                                        Text(
                                            text = pair.phonetic,
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                ExerciseType.SPEAKING -> {
                    val spokenDone = selectedAnswer.isNotBlank()
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (spokenDone) DuoGreenLight else DuoBlueLight
                        ),
                        border = BorderStroke(2.dp, if (spokenDone) DuoGreen else DuoBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Button(
                                onClick = {
                                    onSpeakGerman(question.targetDe, false)
                                    selectedAnswer = question.correctAnswer
                                    onPlaySound(true)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (spokenDone) DuoGreen else DuoBlue
                                ),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.height(54.dp)
                            ) {
                                Text(
                                    text = if (spokenDone) "✅ উচ্চারণ সম্পন্ন হয়েছে!" else "🎙️ ট্যাপ করে জার্মান বাক্যটি বলুন",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (spokenDone)
                                    "চমৎকার উচ্চারণ! এখন নিচে 'যাচাই করুন' বাটনে ট্যাপ করুন।"
                                else
                                    "বাংলা উচ্চারণ দেখে বলুন: “${question.phoneticBn}”",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (spokenDone) DuoGreenDark else DuoBlueDark,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Bottom Feedback & Check/Continue Bar
        Column(modifier = Modifier.fillMaxWidth()) {
            AnimatedVisibility(visible = feedbackState != null) {
                val isCorrect = feedbackState == true
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isCorrect) DuoGreenLight else DuoRedLight
                    ),
                    border = BorderStroke(2.dp, if (isCorrect) DuoGreen else DuoRed),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isCorrect) "✅ চমৎকার! সঠিক উত্তর!" else "❌ সঠিক উত্তর: ${question.correctAnswer}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = if (isCorrect) DuoGreenDark else DuoRedDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "💡 ${question.grammarExplanationBn}",
                            fontSize = 13.sp,
                            color = DuoDarkText
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (feedbackState == null) {
                    OutlinedButton(
                        onClick = { qIndex += 1 },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(54.dp)
                    ) {
                        Text(
                            text = "এড়িয়ে যান",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }

                val canPress = selectedAnswer.isNotBlank() || feedbackState != null
                Button(
                    onClick = {
                        if (feedbackState == null) {
                            val isCorrect = normalizeText(selectedAnswer) == normalizeText(question.correctAnswer)
                            feedbackState = isCorrect
                            onPlaySound(isCorrect)
                            if (!isCorrect) {
                                mistakesCount += 1
                                onLoseHeart()
                            }
                        } else {
                            if (!unlimitedHearts && hearts <= 0) {
                                onRefillHearts()
                            }
                            qIndex += 1
                        }
                    },
                    enabled = canPress,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (feedbackState == false) DuoRed else DuoGreen,
                        disabledContainerColor = Color(0xFFCBD5E1)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1.0f)
                        .height(54.dp)
                ) {
                    Text(
                        text = if (feedbackState == null) "যাচাই করুন (Check)" else "পরবর্তী (Continue)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun StatRewardBox(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DuoSurface),
        border = BorderStroke(2.dp, color),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}

@Composable
fun AlphabetAndGrammarScreen(onSpeakGerman: (String, Boolean) -> Unit) {
    var subTab by remember { mutableIntStateOf(0) } // 0 = Alphabet, 1 = Grammar

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { subTab = 0 },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (subTab == 0) DuoBlue else Color.White,
                    contentColor = if (subTab == 0) Color.White else DuoDarkText
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1.0f)
            ) {
                Text("🔤 বর্ণমালা (৩০টি)", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            }
            Button(
                onClick = { subTab = 1 },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (subTab == 1) DuoBlue else Color.White,
                    contentColor = if (subTab == 1) Color.White else DuoDarkText
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1.0f)
            ) {
                Text("📐 ব্যাকরণ ও কারক", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (subTab == 0) {
            Text(
                text = "যেকোনো বর্ণে ট্যাপ করলে জার্মান উচ্চারণ ও উদাহরণ শুনতে পাবেন:",
                fontSize = 13.sp,
                color = Color(0xFF475569),
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(DeutschCurriculumRepository.alphabetList) { item ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.5.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSpeakGerman(item.wordDe, false) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = DuoBlueLight
                                ) {
                                    Text(
                                        text = item.letter,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = DuoBlueDark,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "উচ্চারণ: ${item.nameBn}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        color = DuoGreenDark
                                    )
                                    Text(
                                        text = "${item.wordDe} — ${item.meaningBn}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = DuoDarkText
                                    )
                                }
                            }
                            Text(text = "🔊", fontSize = 20.sp)
                        }
                    }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(DeutschCurriculumRepository.grammarSections) { sec ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(2.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = sec.titleBn,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = DuoBlueDark
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = sec.subtitleBn,
                                fontSize = 13.sp,
                                color = Color(0xFF475569)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            sec.rows.forEach { row: Triple<String, String, String> ->
                                val col1 = row.first
                                val col2 = row.second
                                val col3 = row.third
                                Surface(
                                    color = DuoSurface,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = col1, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = DuoDarkText)
                                            Text(text = col2, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = DuoGreenDark)
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(text = col3, fontSize = 12.sp, color = Color(0xFF334155))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LeaderboardScreen(
    userXp: Int,
    dailyXp: Int,
    completedCount: Int,
    streak: Int,
    onRewardGems: (Int) -> Unit
) {
    val claimedQuests = remember { mutableStateMapOf<Int, Boolean>() }

    val competitors = remember(userXp) {
        listOf(
            Triple("তানভীর আহমেদ (ঢাকা)", 540, "🇩🇪 B2"),
            Triple("শ্রেয়া মুখার্জি (কলকাতা)", 430, "🇩🇪 B1"),
            Triple("আপনি (You)", userXp, "🇩🇪 A1–C1"),
            Triple("নুসরাত জাহান (চট্টগ্রাম)", 310, "🇩🇪 A2"),
            Triple("অরিন্দম সেন (শিলিগুড়ি)", 245, "🇩🇪 A2"),
            Triple("ফারহানা ইসলাম", 180, "🇩🇪 A1")
        ).sortedByDescending { it.second }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(2.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎯 দৈনিক কোয়েস্ট (Daily Quests)",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DuoDarkText
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    val quests = listOf(
                        Triple(1, "আজ ৫০ XP অর্জন করুন ($dailyXp/50)", dailyXp >= 50),
                        Triple(2, "২টি পাঠ সম্পন্ন করুন ($completedCount/2)", completedCount >= 2),
                        Triple(3, "৭ দিনের স্ট্রিক বজায় রাখুন ($streak/7)", streak >= 7)
                    )
                    quests.forEach { (id, title, done) ->
                        val claimed = claimedQuests[id] == true
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                modifier = Modifier.weight(1.0f)
                            )
                            Button(
                                onClick = {
                                    if (done && !claimed) {
                                        claimedQuests[id] = true
                                        onRewardGems(35)
                                    }
                                },
                                enabled = done && !claimed,
                                colors = ButtonDefaults.buttonColors(containerColor = DuoGold),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = if (claimed) "✅ সংগৃহীত" else "+35 💎",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = DuoDarkText
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "🏆 এমেরাল্ড লিগ (Emerald League)",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = DuoDarkText
            )
        }

        itemsIndexed(competitors) { idx, (name, score, level) ->
            val isUser = name.contains("আপনি")
            val medal = when (idx) {
                0 -> "🥇"
                1 -> "🥈"
                2 -> "🥉"
                else -> "#${idx + 1}"
            }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isUser) DuoGreenLight else Color.White
                ),
                border = BorderStroke(
                    width = if (isUser) 2.5.dp else 1.dp,
                    color = if (isUser) DuoGreen else Color(0xFFE2E8F0)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = medal, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = name, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = DuoDarkText)
                            Text(text = level, fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                    Text(
                        text = "$score XP",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = DuoGreenDark
                    )
                }
            }
        }
    }
}

@Composable
fun ShopScreen(
    gems: Int,
    hearts: Int,
    unlimitedHearts: Boolean,
    doubleXpBoost: Boolean,
    onBuyHeartRefill: () -> Unit,
    onBuyDoubleXp: () -> Unit,
    onBuyUnlimitedHearts: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DuoBlueLight),
            border = BorderStroke(2.dp, DuoBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "🛒 ডুও-জার্মান শপ", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = DuoDarkText)
                    Text(text = "পাঠ সম্পন্ন করে অর্জিত জেমস দিয়ে পাওয়ার-আপ কিনুন", fontSize = 12.sp, color = Color.DarkGray)
                }
                Text(text = "💎 $gems", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = DuoBlueDark)
            }
        }

        ShopItemCard(
            icon = "❤️",
            title = "সম্পূর্ণ হার্ট রিফিল (Full Hearts)",
            desc = "আপনার ৫টি হার্ট সাথে সাথে পূর্ণ করুন (বর্তমান: ${if (unlimitedHearts) "♾️" else "$hearts/5"})",
            buttonText = if (hearts >= 5 || unlimitedHearts) "পূর্ণ আছে" else "💎 100",
            enabled = !unlimitedHearts && hearts < 5 && gems >= 100,
            onClick = onBuyHeartRefill
        )

        ShopItemCard(
            icon = "⚡",
            title = "ডাবল XP বুস্ট (2x XP Boost)",
            desc = "প্রতিটি পাঠে দ্বিগুণ অভিজ্ঞতা (2x XP) অর্জন করুন!",
            buttonText = if (doubleXpBoost) "সক্রিয় আছে" else "💎 150",
            enabled = !doubleXpBoost && gems >= 150,
            onClick = onBuyDoubleXp
        )

        ShopItemCard(
            icon = "👑",
            title = "সুপার ডুও-জার্মান (Unlimited Hearts)",
            desc = "অসীম হার্টস (♾️) চালু করুন — ভুল উত্তরে কোনো হার্ট কমবে না!",
            buttonText = if (unlimitedHearts) "সক্রিয় (♾️)" else "💎 300",
            enabled = !unlimitedHearts && gems >= 300,
            onClick = onBuyUnlimitedHearts
        )
    }
}

@Composable
fun ShopItemCard(
    icon: String,
    title: String,
    desc: String,
    buttonText: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1.0f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = icon, fontSize = 30.sp)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = DuoDarkText)
                    Text(text = desc, fontSize = 12.sp, color = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Button(
                onClick = onClick,
                enabled = enabled,
                colors = ButtonDefaults.buttonColors(containerColor = DuoBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(text = buttonText, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }
}

@Composable
fun ProfileScreen(
    xp: Int,
    streak: Int,
    gems: Int,
    completedLessons: Int,
    totalLessons: Int,
    onResetProgress: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(2.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = DuoGreen,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = "🇩🇪", fontSize = 32.sp)
                        }
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "বাংলা → জার্মান শিক্ষার্থী",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = DuoDarkText
                        )
                        Text(
                            text = "Complete Course: Beginner A1 → Pro C1/C2",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatRewardBox(title = "স্ট্রিক", value = "🔥 $streak দিন", color = DuoOrange, modifier = Modifier.weight(1.0f))
                    StatRewardBox(title = "মোট XP", value = "⚡ $xp", color = DuoGreenDark, modifier = Modifier.weight(1.0f))
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatRewardBox(title = "সম্পন্ন পাঠ", value = "👑 $completedLessons/$totalLessons", color = DuoBlue, modifier = Modifier.weight(1.0f))
                    StatRewardBox(title = "জেমস", value = "💎 $gems", color = DuoPurple, modifier = Modifier.weight(1.0f))
                }
            }
        }

        OutlinedButton(
            onClick = onResetProgress,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "🔄 অগ্রগতি রিসেট করুন (Reset Progress)",
                fontWeight = FontWeight.Bold,
                color = DuoRed
            )
        }
    }
}
