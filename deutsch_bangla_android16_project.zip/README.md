# ডুও-জার্মান (DeutschBangla) — Modern Android 16 (API 36) Duolingo Clone

বাংলা ভাষাভাষীদের জন্য **জার্মান ভাষা (Beginner A1 থেকে Professional C1/C2)** শেখার একটি পূর্ণাঙ্গ Duolingo-স্টাইল অ্যান্ড্রয়েড অ্যাপ।

## Tech Stack (Modern Android 16 / Baklava)
- **Target & Compile SDK:** Android 16 (`API 36`)
- **UI Framework:** Jetpack Compose + Material 3 (`1.3.1`)
- **Language:** Kotlin `2.1.0`
- **Android 16 Native Features:**
  - `enableEdgeToEdge()` system bar integration
  - Android 16 Predictive Back gesture (`android:enableOnBackInvokedCallback="true"` & Compose `BackHandler`)
  - Native Android `TextToSpeech` (`Locale.GERMAN`) with normal (1.0x) and turtle slow (0.6x) audio playback

## How to Run in Android Studio
1. Unzip `deutsch_bangla_android16_project.zip`.
2. Open **Android Studio Ladybug / Meerkat (2024.3+)** and select **Open**.
3. Choose the `DeutschBanglaAndroid16` folder and let Gradle sync.
4. Run on an **Android 16 (API 36)** emulator or physical Android device.
