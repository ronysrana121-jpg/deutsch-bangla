package com.deutschbangla.duolingo.model

enum class ExerciseType {
    WORD_BANK,
    MULTIPLE_CHOICE,
    MATCH_PAIRS,
    LISTENING,
    SPEAKING,
    FILL_BLANK
}

data class MatchPair(
    val bengali: String,
    val german: String,
    val phonetic: String
)

data class Question(
    val id: String,
    val type: ExerciseType,
    val promptBn: String,
    val targetDe: String,
    val phoneticBn: String,
    val correctAnswer: String,
    val options: List<String> = emptyList(),
    val pairs: List<MatchPair> = emptyList(),
    val grammarExplanationBn: String = ""
)

data class LessonNode(
    val id: String,
    val unitId: Int,
    val titleBn: String,
    val subtitleDe: String,
    val cefrLevel: String,
    val iconEmoji: String,
    val xpReward: Int = 20,
    val questions: List<Question>
)

data class CourseUnit(
    val id: Int,
    val cefrLevel: String,
    val titleBn: String,
    val descriptionBn: String,
    val colorHex: Long,
    val guidebookNotesBn: List<String>,
    val lessons: List<LessonNode>
)

object DeutschCurriculumRepository {
    val units: List<CourseUnit> = listOf(
        CourseUnit(
            id = 1,
            cefrLevel = "A1.1 • প্রাথমিক স্তর (Beginner)",
            titleBn = "ইউনিট ১: অভিবাদন ও পরিচয় (Greetings & Intro)",
            descriptionBn = "জার্মান ভাষায় কুশল বিনিময়, ধন্যবাদ জানানো এবং নিজের পরিচয় দেওয়া শিখুন।",
            colorHex = 0xFF58CC02,
            guidebookNotesBn = listOf(
                "Hallo (হ্যালো) — যেকোনো সময় বন্ধু বা পরিচিতদের সম্ভাষণ জানাতে ব্যবহৃত হয়।",
                "Guten Morgen (গুটেন মর্গেন) — শুভ সকাল (সকাল থেকে দুপুর ১২টা পর্যন্ত)।",
                "Ich bin... (ইখ বিন...) — 'আমি হলাম...'। যেমন: Ich bin Rahim (আমি রহিম)।",
                "Danke (ডাঙ্কে) = ধন্যবাদ, এবং Bitte (বিটে) = দয়া করে / আপনাকে স্বাগতম।"
            ),
            lessons = listOf(
                LessonNode(
                    id = "u1_l1",
                    unitId = 1,
                    titleBn = "অভিবাদন ১ (Greetings)",
                    subtitleDe = "Hallo & Guten Morgen",
                    cefrLevel = "A1",
                    iconEmoji = "👋",
                    questions = listOf(
                        Question(
                            id = "q1",
                            type = ExerciseType.MULTIPLE_CHOICE,
                            promptBn = "‘শুভ সকাল’ এর সঠিক জার্মান কোনটি?",
                            targetDe = "Guten Morgen",
                            phoneticBn = "গুটেন মর্গেন",
                            correctAnswer = "Guten Morgen",
                            options = listOf("Guten Morgen", "Gute Nacht", "Auf Wiedersehen", "Danke schön"),
                            grammarExplanationBn = "সকালে দেখা হলে জার্মানরা 'Guten Morgen' (শুভ সকাল) বলে।"
                        ),
                        Question(
                            id = "q2",
                            type = ExerciseType.WORD_BANK,
                            promptBn = "শব্দ সাজিয়ে অনুবাদ করুন: হ্যালো, আমি অনিক।",
                            targetDe = "Hallo ich bin Anik",
                            phoneticBn = "হ্যালো ইখ বিন অনিক",
                            correctAnswer = "Hallo ich bin Anik",
                            options = listOf("Hallo", "ich", "bin", "Anik", "du", "bist", "Danke"),
                            grammarExplanationBn = "'Ich bin' মানে 'আমি হলাম'।"
                        ),
                        Question(
                            id = "q3",
                            type = ExerciseType.MATCH_PAIRS,
                            promptBn = "বাংলা ও জার্মান শব্দের জোড়া মেলান",
                            targetDe = "Hallo • Danke • Bitte • Ja • Nein",
                            phoneticBn = "হ্যালো • ডাঙ্কে • বিটে • ইয়া • নাইন",
                            correctAnswer = "MATCHED",
                            pairs = listOf(
                                MatchPair("হ্যালো", "Hallo", "হ্যালো"),
                                MatchPair("ধন্যবাদ", "Danke", "ডাঙ্কে"),
                                MatchPair("দয়া করে", "Bitte", "বিটে"),
                                MatchPair("হ্যাঁ", "Ja", "ইয়া"),
                                MatchPair("না", "Nein", "নাইন")
                            )
                        ),
                        Question(
                            id = "q4",
                            type = ExerciseType.LISTENING,
                            promptBn = "অডিওটি শুনে সঠিক জার্মান বাক্যটি সাজান (অর্থ: অনেক ধন্যবাদ)",
                            targetDe = "Vielen Dank",
                            phoneticBn = "ফিলেন ডাঙ্ক",
                            correctAnswer = "Vielen Dank",
                            options = listOf("Vielen", "Dank", "Guten", "Tag", "Bitte")
                        ),
                        Question(
                            id = "q5",
                            type = ExerciseType.SPEAKING,
                            promptBn = "জোরে উচ্চারণ করুন: শুভ দিন, আপনি কেমন আছেন?",
                            targetDe = "Guten Tag wie geht es dir",
                            phoneticBn = "গুটেন টাগ, ভি গেট এস ডিয়ার?",
                            correctAnswer = "Guten Tag wie geht es dir"
                        )
                    )
                )
            )
        ),
        CourseUnit(
            id = 2,
            cefrLevel = "A2 • প্রাত্যহিক জীবন (Elementary)",
            titleBn = "ইউনিট ২: খাবার, পরিবার ও কেনাকাটা",
            descriptionBn = "রেস্তোরাঁয় খাবার অর্ডার করা, পরিবারের সদস্য ও জার্মান আর্টিকেল (der/die/das) শিখুন।",
            colorHex = 0xFF1CB0F6,
            guidebookNotesBn = listOf(
                "জার্মান ভাষায় প্রতিটি বিশেষ্যের (Noun) প্রথম অক্ষর বড় হাতের হয় (যেমন: das Wasser, das Brot)।",
                "তিনটি ব্যাকরণগত লিঙ্গ রয়েছে: der (পুংলিঙ্গ), die (স্ত্রীলিঙ্গ), das (ক্লীবলিঙ্গ)।"
            ),
            lessons = emptyList()
        ),
        CourseUnit(
            id = 3,
            cefrLevel = "B1 • মধ্যম স্তর (Intermediate)",
            titleBn = "ইউনিট ৩: ভ্রমণ, দিকনির্দেশ ও স্বাস্থ্য",
            descriptionBn = "ট্রেন স্টেশন, বিমানবন্দর, রাস্তা খোঁজা এবং জরুরি কথোপকথন আয়ত্ত করুন।",
            colorHex = 0xFFFF9600,
            guidebookNotesBn = listOf(
                "Wo ist...? (ভো ইস্ট...?) — '...কোথায়?' যেমন: Wo ist der Bahnhof? (রেল স্টেশন কোথায়?)",
                "Ich möchte... (ইখ মশটে...) — 'আমি চাই...' (ভদ্রভাবে কিছু চাওয়ার জন্য ব্যবহৃত হয়)।"
            ),
            lessons = emptyList()
        ),
        CourseUnit(
            id = 4,
            cefrLevel = "B2 • উচ্চ-মধ্যম স্তর (Upper-Intermediate)",
            titleBn = "ইউনিট ৪: কর্মক্ষেত্র, অফিস ও ক্যারিয়ার",
            descriptionBn = "চাকরির ইন্টারভিউ, অফিসের মিটিং এবং পেশাদার ইমেইল লেখার জার্মান শিখুন।",
            colorHex = 0xFFCE82FF,
            guidebookNotesBn = listOf(
                "অফিস ও পেশাদার পরিবেশে সর্বদা 'Sie' (আপনি - ফরমাল) ব্যবহার করা হয়, 'du' (তুমি) নয়।",
                "Ich arbeite als... (ইখ আরবাইটে আলস...) — 'আমি ... হিসেবে কাজ করি'।"
            ),
            lessons = emptyList()
        ),
        CourseUnit(
            id = 5,
            cefrLevel = "C1/C2 • পেশাদার স্তর (Professional)",
            titleBn = "ইউনিট ৫: ব্যবসা, প্রযুক্তি ও একাডেমিক জার্মান",
            descriptionBn = "চুক্তি আলোচনা, কর্পোরেট প্রেজেন্টেশন, গবেষণা ও উন্নত ব্যাকরণ (Konjunktiv II / Genitiv)।",
            colorHex = 0xFFFF4B4B,
            guidebookNotesBn = listOf(
                "Meines Erachtens (মাইনেস এরআখটেন্স) — 'আমার মতে' (পেশাদার আলোচনায় ব্যবহৃত)।",
                "Sehr geehrte Damen und Herren — ফরমাল চিঠির শুরুতে 'মহোদয় ও মহোদয়াগণ'।"
            ),
            lessons = emptyList()
        )
    )
}
