package com.deutschbangla.duolingo.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DuoGreen = Color(0xFF58CC02)
val DuoGreenDark = Color(0xFF46A302)
val DuoBlue = Color(0xFF1CB0F6)
val DuoBlueDark = Color(0xFF1899D6)
val DuoRed = Color(0xFFFF4B4B)
val DuoGold = Color(0xFFFFC800)
val DuoPurple = Color(0xFFCE82FF)
val DuoOrange = Color(0xFFFF9600)
val DuoSurface = Color(0xFFF7F9FA)

private val LightColors = lightColorScheme(
    primary = DuoGreen,
    onPrimary = Color.White,
    secondary = DuoBlue,
    onSecondary = Color.White,
    tertiary = DuoGold,
    error = DuoRed,
    background = Color.White,
    surface = DuoSurface
)

@Composable
fun DeutschBanglaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}
