package com.deutschbangla.duolingo

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.deutschbangla.duolingo.model.*
import com.deutschbangla.duolingo.ui.theme.*
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Modern Android 16 Edge-to-Edge display support
        enableEdgeToEdge()
        tts = TextToSpeech(this, this)

        setContent {
            DeutschBanglaTheme {
                DeutschBanglaApp(
                    onSpeakGerman = { text, slow ->
                        tts?.setSpeechRate(if (slow) 0.6f else 1.0f)
                        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "de_tts")
                    }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.GERMAN
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeutschBanglaApp(onSpeakGerman: (String, Boolean) -> Unit) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var xp by remember { mutableIntStateOf(340) }
    var streak by remember { mutableIntStateOf(7) }
    var gems by remember { mutableIntStateOf(450) }
    var hearts by remember { mutableIntStateOf(5) }
    var activeLesson by remember { mutableStateOf<LessonNode?>(null) }

    // Android 16 Predictive Back handling when inside an active lesson
    BackHandler(enabled = activeLesson != null) {
        activeLesson = null
    }

    Scaffold(
        topBar = {
            if (activeLesson == null) {
                TopGamificationBar(streak = streak, gems = gems, hearts = hearts, xp = xp)
            }
        },
        bottomBar = {
            if (activeLesson == null) {
                NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                    val tabs = listOf(
                        "শেখা" to Icons.Default.Home,
                        "বর্ণমালা" to Icons.Default.Translate,
                        "লিডারবোর্ড" to Icons.Default.EmojiEvents,
                        "শপ" to Icons.Default.Storefront,
                        "প্রোফাইল" to Icons.Default.Person
                    )
                    tabs.forEachIndexed { index, pair ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(pair.second, contentDescription = pair.first) },
                            label = { Text(pair.first, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            if (activeLesson != null) {
                LessonScreen(
                    lesson = activeLesson!!,
                    hearts = hearts,
                    onLoseHeart = { if (hearts > 0) hearts-- },
                    onSpeakGerman = onSpeakGerman,
                    onFinishLesson = { earnedXp ->
                        xp += earnedXp
                        gems += 15
                        activeLesson = null
                    },
                    onClose = { activeLesson = null }
                )
            } else {
                when (selectedTab) {
                    0 -> LearningPathTab(
                        units = DeutschCurriculumRepository.units,
                        onStartLesson = { lesson ->
                            if (hearts > 0) activeLesson = lesson
                        },
                        onSpeakGerman = onSpeakGerman
                    )
                    1 -> AlphabetGrammarTab(onSpeakGerman = onSpeakGerman)
                    2 -> LeaderboardTab(xp = xp)
                    3 -> GemShopTab(
                        gems = gems,
                        hearts = hearts,
                        onBuyHearts = {
                            if (gems >= 100 && hearts < 5) {
                                gems -= 100
                                hearts = 5
                            }
                        }
                    )
                    4 -> ProfileTab(xp = xp, streak = streak, gems = gems)
                }
            }
        }
    }
}

@Composable
fun TopGamificationBar(streak: Int, gems: Int, hearts: Int, xp: Int) {
    Surface(shadowElevation = 4.dp, color = Color.White) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🇩🇪 বাংলা → জার্মান", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("🔥 $streak", fontWeight = FontWeight.Bold, color = DuoOrange)
                Text("💎 $gems", fontWeight = FontWeight.Bold, color = DuoBlue)
                Text("⚡ $xp XP", fontWeight = FontWeight.Bold, color = DuoGold)
                Text("❤️ $hearts", fontWeight = FontWeight.Bold, color = DuoRed)
            }
        }
    }
}

@Composable
fun LearningPathTab(
    units: List<CourseUnit>,
    onStartLesson: (LessonNode) -> Unit,
    onSpeakGerman: (String, Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        items(units) { unit ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(unit.colorHex))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(unit.cefrLevel, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(unit.titleBn, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(4.dp))
                    Text(unit.descriptionBn, color = Color.White.copy(alpha = 0.95f), fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            unit.lessons.forEach { lesson ->
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .clip(CircleShape)
                        .background(Color(unit.colorHex))
                        .border(4.dp, Color.White, CircleShape)
                        .clickable { onStartLesson(lesson) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(lesson.iconEmoji, fontSize = 32.sp)
                }
                Text(lesson.titleBn, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                Text(lesson.subtitleDe, fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LessonScreen(
    lesson: LessonNode,
    hearts: Int,
    onLoseHeart: () -> Unit,
    onSpeakGerman: (String, Boolean) -> Unit,
    onFinishLesson: (Int) -> Unit,
    onClose: () -> Unit
) {
    var qIndex by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableStateOf("") }
    var wordBankSelection by remember { mutableStateOf(listOf<String>()) }
    var feedbackState by remember { mutableStateOf<Boolean?>(null) }

    val question = lesson.questions.getOrNull(qIndex)
    if (question == null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🎉 পাঠ সম্পন্ন হয়েছে!", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = DuoGreen)
            Spacer(Modifier.height(12.dp))
            Text("আপনি +${lesson.xpReward} XP এবং +15 Gems অর্জন করেছেন!", fontSize = 16.sp)
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { onFinishLesson(lesson.xpReward) },
                colors = ButtonDefaults.buttonColors(containerColor = DuoGreen),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Text("চালিয়ে যান (Continue)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = "Close") }
                LinearProgressIndicator(
                    progress = { (qIndex.toFloat()) / lesson.questions.size.coerceAtLeast(1) },
                    modifier = Modifier.weight(1f).height(12.dp).clip(RoundedCornerShape(6.dp)),
                    color = DuoGreen
                )
                Spacer(Modifier.width(12.dp))
                Text("❤️ $hearts", fontWeight = FontWeight.Bold, color = DuoRed)
            }
            Spacer(Modifier.height(20.dp))
            Text(question.promptBn, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(DuoSurface)
                    .clickable { onSpeakGerman(question.targetDe, false) }
                    .padding(14.dp)
            ) {
                Icon(Icons.Default.VolumeUp, contentDescription = "Speak", tint = DuoBlue)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(question.targetDe, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("উচ্চারণ: ${question.phoneticBn}", fontSize = 13.sp, color = Color.DarkGray)
                }
            }
            Spacer(Modifier.height(24.dp))

            when (question.type) {
                ExerciseType.MULTIPLE_CHOICE, ExerciseType.FILL_BLANK -> {
                    question.options.forEach { option ->
                        OutlinedButton(
                            onClick = { selectedAnswer = option },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).height(54.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(option, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                ExerciseType.WORD_BANK, ExerciseType.LISTENING -> {
                    Text("আপনার বাক্য: ${wordBankSelection.joinToString(" ")}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(14.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        question.options.forEach { word ->
                            FilterChip(
                                selected = wordBankSelection.contains(word),
                                onClick = {
                                    wordBankSelection = if (wordBankSelection.contains(word)) {
                                        wordBankSelection - word
                                    } else {
                                        wordBankSelection + word
                                    }
                                    selectedAnswer = wordBankSelection.joinToString(" ")
                                },
                                label = { Text(word, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }
                }
                else -> {
                    Button(
                        onClick = {
                            onSpeakGerman(question.targetDe, false)
                            selectedAnswer = question.correctAnswer
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DuoBlue),
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text("🎙️ উচ্চারণ পরীক্ষা করুন / মিলিয়ে নিন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Column {
            AnimatedVisibility(visible = feedbackState != null) {
                val isCorrect = feedbackState == true
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isCorrect) Color(0xFFD7FFB8) else Color(0xFFFFDFE0)
                    ),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            if (isCorrect) "✅ চমৎকার! সঠিক উত্তর!" else "❌ সঠিক উত্তর: ${question.correctAnswer}",
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isCorrect) DuoGreenDark else DuoRed
                        )
                        if (question.grammarExplanationBn.isNotEmpty()) {
                            Text(question.grammarExplanationBn, fontSize = 13.sp)
                        }
                    }
                }
            }

            Button(
                onClick = {
                    if (feedbackState == null) {
                        val correct = selectedAnswer.trim().equals(question.correctAnswer.trim(), ignoreCase = true)
                        feedbackState = correct
                        if (!correct) onLoseHeart()
                    } else {
                        feedbackState = null
                        selectedAnswer = ""
                        wordBankSelection = emptyList()
                        qIndex++
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DuoGreen),
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    if (feedbackState == null) "যাচাই করুন (Check)" else "পরবর্তী (Next)",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

@Composable
fun AlphabetGrammarTab(onSpeakGerman: (String, Boolean) -> Unit) {
    val letters = listOf(
        Triple("A a", "আ (Apfel - আপেল)", "Apfel"),
        Triple("B b", "বে (Brot - রুটি)", "Brot"),
        Triple("C c", "ৎসে (Café - ক্যাফে)", "Café"),
        Triple("D d", "ডে (Danke - ধন্যবাদ)", "Danke"),
        Triple("Ä ä", "এ্যা (Ärztin - মহিলা ডাক্তার)", "Ärztin"),
        Triple("Ö ö", "ওয়ে (Österreich - অস্ট্রিয়া)", "Österreich"),
        Triple("Ü ü", "উই (Übung - অনুশীলন)", "Übung"),
        Triple("ß", "এসৎসেট (Straße - রাস্তা)", "Straße")
    )
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("জার্মান বর্ণমালা ও উচ্চারণ (Alphabet & Umlauts)", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("যেকোনো বর্ণে ট্যাপ করে জার্মান উচ্চারণ শুনুন", fontSize = 14.sp, color = Color.Gray)
        }
        items(letters) { item ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onSpeakGerman(item.third, false) },
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(item.first, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = DuoBlue)
                    Spacer(Modifier.width(16.dp))
                    Text(item.second, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun LeaderboardTab(xp: Int) {
    val ranks = listOf(
        "১. তানভীর আহমেদ (ঢাকা)" to 620,
        "২. আপনি (You - বাংলা শিক্ষার্থী)" to xp,
        "৩. শ্রেয়া মুখার্জি (কলকাতা)" to 310,
        "৪. নুসরাত জাহান" to 275,
        "৫. রাহুল সেন" to 190
    )
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("🏆 এমেরাল্ড লিগ (Emerald League)", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("শীর্ষ ৩ জন পরবর্তী ডায়মন্ড লিগে উন্নীত হবেন!", fontSize = 14.sp, color = Color.Gray)
        }
        items(ranks) { (name, score) ->
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("$score XP", fontWeight = FontWeight.ExtraBold, color = DuoGreenDark)
                }
            }
        }
    }
}

@Composable
fun GemShopTab(gems: Int, hearts: Int, onBuyHearts: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("🛒 ডুও-জার্মান শপ (Gem Shop)", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text("আপনার বর্তমান ব্যালেন্স: 💎 $gems Gems", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = DuoBlue)
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("❤️ সম্পূর্ণ হার্ট রিফিল (Full Hearts)", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Text("৫টি হার্ট সাথে সাথে ফিরে পান (বর্তমান: $hearts/5)", fontSize = 13.sp, color = Color.Gray)
                }
                Button(onClick = onBuyHearts, enabled = gems >= 100 && hearts < 5) {
                    Text("💎 100")
                }
            }
        }
    }
}

@Composable
fun ProfileTab(xp: Int, streak: Int, gems: Int) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("👤 শিক্ষার্থী প্রোফাইল (Learner Profile)", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text("কোর্স: বাংলা থেকে জার্মান (A1 Beginner → C1 Professional)", fontSize = 15.sp, color = Color.DarkGray)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Card(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("🔥 $streak দিন", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text("স্ট্রিক (Streak)", fontSize = 13.sp)
                }
            }
            Card(modifier = Modifier.weight(1f)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("⚡ $xp XP", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text("মোট অভিজ্ঞতা", fontSize = 13.sp)
                }
            }
        }
    }
}
